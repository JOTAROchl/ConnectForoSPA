package com.example.categoria.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.categoria.model.categoria;
import com.example.categoria.repository.categoriaRepository;
import com.example.categoria.services.categoriaServices;

@ExtendWith(MockitoExtension.class)
public class CategoriaServiceTest {
    @Mock
    private categoriaRepository repository;
    
    @InjectMocks
    private categoriaServices service;

    @Test
    void saveCategoria_returnsSavedCategoria(){
        //creamos un objeto de prueba para el insert
        categoria nuevaCategoria = new categoria(1L, "Animales");
        //configuramos la respuesta del repositorio
        
        when(repository.save(nuevaCategoria)).thenReturn(nuevaCategoria);

        //ejecutamos el metodo del servicio a comprobar
        categoria result = service.saveCategoria(nuevaCategoria);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevaCategoria); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getCategorias_returnsListOfCategorias() {

        List<categoria> mockList = Arrays.asList(
            new categoria(1L, "Animales"), new categoria(2L, "Tecnologia"));
        when(repository.findAll()).thenReturn(mockList);
        List<categoria> result = service.getCategorias();
        assertThat(result).isEqualTo(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getCategoriaPorId_returnsCategoria() { 
        //creamos un objeto de prueba para el insert
        categoria categoria = new categoria(1L, "Animales");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(categoria));

        //ejecutamos el metodo del servicio a comprobar
        categoria result = service.getCategoria(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(categoria); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateCategoria_returnsUpdatedCategoria() {
        //creamos un objeto de prueba para el insert
        categoria categoria = new categoria(1L, "Animales");
        categoria categoriaDetails = new categoria(1L, "Mascotas");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(categoria));
        when(repository.save(categoriaDetails)).thenReturn(categoriaDetails);

        //ejecutamos el metodo del servicio a comprobar
        categoria result = service.updateCategoria(1L, categoriaDetails);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(categoriaDetails); //el mismo objeto
    }  
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteCategoria_deletesCategoria() {  
        //creamos un objeto de prueba para el insert
        categoria categoria = new categoria(1L, "Animales");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(categoria));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteCategoria(1L);

        //verificamos que el repositorio haya llamado al metodo delete con la categoria correcta
        assertThat(repository.findById(1L).isEmpty());
    }


}
