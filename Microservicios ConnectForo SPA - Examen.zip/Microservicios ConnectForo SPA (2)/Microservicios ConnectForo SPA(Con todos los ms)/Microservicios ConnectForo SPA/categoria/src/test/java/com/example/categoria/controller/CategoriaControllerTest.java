package com.example.categoria.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.categoria.model.categoria;
import com.example.categoria.services.categoriaServices;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

@WebMvcTest(categoriaController.class)
public class CategoriaControllerTest {

    @MockBean
    private categoriaServices categoriaServices;
    
    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllReservas_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<categoria> categorias = Arrays.asList(new categoria(1L, "Animales"));

        //configuro el comportamiento del servicio simulado
        when(categoriaServices.getCategorias()).thenReturn(categorias);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/categorias")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getCategoriaPorId_returnsOKAndJson() {
        //creamos una reserva de ejemplo
        categoria categoria = new categoria(1L, "Animales");

        //configuro el comportamiento del servicio simulado
        when(categoriaServices.getCategoria(1L)).thenReturn(categoria);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/categorias/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void saveCategoria_returnsCreatedAndJson() {
        //creamos una reserva de ejemplo
        categoria nuevaCategoria = new categoria(1L, "Animales");

        //configuro el comportamiento del servicio simulado
        when(categoriaServices.saveCategoria(nuevaCategoria)).thenReturn(nuevaCategoria);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201
        try {
            mockMvc.perform(post("/api/v1/categorias")
                .contentType("application/json")
                .content("{\"id\":1,\"nombreCategoria\":\"Animales\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id")
                .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateCategoria_returnsOkAndJson() {
        //creamos una reserva de ejemplo
        categoria categoriaDetails = new categoria(1L, "Mascotas");

        //configuro el comportamiento del servicio simulado
        when(categoriaServices.updateCategoria(1L, categoriaDetails)).thenReturn(categoriaDetails);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(put("/api/v1/categorias/1")
                .contentType("application/json")
                .content("{\"id\":1,\"nombreCategoria\":\"Mascotas\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id")
                .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
}
