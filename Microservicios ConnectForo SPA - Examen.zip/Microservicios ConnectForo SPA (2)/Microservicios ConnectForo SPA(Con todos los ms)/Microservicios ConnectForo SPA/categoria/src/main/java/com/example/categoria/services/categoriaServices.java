package com.example.categoria.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.categoria.model.categoria;
import com.example.categoria.repository.categoriaRepository;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class categoriaServices{
    @Autowired
    private categoriaRepository categoriaRepository;

    @Schema(description = "Metodo para obtener todas las categorias")
    public List<categoria> getCategorias(){
        return categoriaRepository.findAll();
    }

    @Schema(description = "Metodo para obtener una categoria por su id")
    public categoria getCategoria(Long id) {
        return categoriaRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Categoria no encontrada"));
    }

    @Schema(description = "Metodo para guardar una categoria")
    public categoria saveCategoria(categoria categoria){
        if (categoriaRepository.findByNombreCategoria(categoria.getNombreCategoria()).isPresent()) {
            throw new RuntimeException("********************** Categoria ya existe **********************");
        }
        return categoriaRepository.save(categoria);
    }

    @Schema(description = "Metodo para actulizar una categoria y sus datos")
    public categoria updateCategoria(Long id, categoria categoriaDetails){
        categoria categoria = categoriaRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Categoria no encontrada"));
        //actualiza
        categoria.setNombreCategoria(categoriaDetails.getNombreCategoria());
        //guarda
        return categoriaRepository.save(categoria);
    }

    @Schema(description = "Metodo para eliminar una categoria")
    public void deleteCategoria(long id){
        categoria categoria = categoriaRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Categoria no encontrada"));
        categoriaRepository.delete(categoria);
    }
}
