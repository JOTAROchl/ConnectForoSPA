package com.example.categoria.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.categoria.model.categoria;
import com.example.categoria.services.categoriaServices;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/categorias")

public class categoriaController {
    @Autowired
    private categoriaServices categoriaServices;

    @Operation(summary = "EndPoint para encontrar todos las Categorias")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos las Categorias",
        content=@Content(schema=@Schema(implementation=categoria.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Categoria registrado",
        content =@Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = categoria.class)))
    })
    @GetMapping
    public ResponseEntity<List<categoria>> obtenerCategorias() {
        List<categoria> categoria = categoriaServices.getCategorias();
        if(categoria.isEmpty()){ // verifica si la lista de categorias está vacía o no
            return ResponseEntity.noContent().build(); // si está vacía, devolverá el codigo 204 (No Content)
        }
        return ResponseEntity.ok(categoria); // si no está vacía, devolverá el codigo 200 (OK) con todas las listas de las categorias
    }

    @Operation(summary = "EndPoint para encontrar una sola Categoria por Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró la Categoria por Id",
        content=@Content(schema=@Schema(implementation=categoria.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = categoria.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<categoria> obtenerCategoriaPorId(@PathVariable Long id){
        try{
            categoria categoria = categoriaServices.getCategoria(id);
            return ResponseEntity.ok(categoria);
        } catch (Exception e){
            return ResponseEntity.notFound().build();
            // si no encuentra la categoria, devolverá el codigo 404 (Not Found)
        }
    }

    @Operation(summary = "EndPoint para guardar una Categoria")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Categoria guardada exitosamente",
        content=@Content(schema=@Schema(implementation=categoria.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = categoria.class)))
    })
    @PostMapping
    public ResponseEntity<categoria> guardarCategoria(@RequestBody categoria categoria){
        return ResponseEntity.status(201).body(categoriaServices.saveCategoria(categoria));// devolverá el codigo 201 (Created) con la categoria creada
    }

    @Operation(summary = "EndPoint para actualizar una Categoria y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Categoria actualizada exitosamente",
        content=@Content(schema=@Schema(implementation=categoria.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="404", description="No se encontró la categoria",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = categoria.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<categoria> actualizarCategoria(@PathVariable Long id, @RequestBody categoria categoria){
        try{
            categoria categoriaActualizada = categoriaServices.updateCategoria(id, categoria);
            return ResponseEntity.ok(categoriaActualizada); // devolverá el codigo 200 (OK) con la categoria actualizada
        } catch (Exception e){
            return ResponseEntity.notFound().build(); // si no encuentra la categoria, devolverá el codigo 404 (Not Found)
        }
    }

    @Operation(summary = "EndPoint para eliminar una categoria")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Categoria eliminada exitosamente",
        content=@Content(schema=@Schema(implementation=categoria.class))),
        @ApiResponse(responseCode="404", description="No se encontró la categoria",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = categoria.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = categoria.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCategoria(@PathVariable Long id){
        try{
            categoriaServices.deleteCategoria(id); // llama al servicio para eliminar la categoria por id
            return ResponseEntity.noContent().build();// devolverá el codigo 204 (No Content) si la categoria se elimina correctamente
        } catch (Exception e){
            return ResponseEntity.notFound().build(); // si no encuentra la categoria, devolverá el codigo 404 (Not Found)
        }
    }
}
