package com.example.categoria.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.categoria.model.categoria;

@Repository
public interface categoriaRepository extends JpaRepository<categoria, Long> {

    Optional<categoria> findByNombreCategoria(String nombreCategoria);
}
