package com.example.comentario.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.comentario.model.Comentario;
import com.example.comentario.repository.ComentarioRepository;

@ExtendWith(MockitoExtension.class)
public class ComentarioServiceTest {
    @Mock
    private ComentarioRepository repository;

    @InjectMocks
    private ComentarioService service;

    @Test
    void save_returnsSavedComentario(){
        //creamos un objeto de prueba para el insert
        Comentario nuevoComentario = new Comentario(1L,"Comentario", new Date(0),"alta","publicacion de perritos","Los perritos son muy bonitos",1L,1L,1L);

        //configuramos la respuesta del repositorio
        when(repository.save(nuevoComentario)).thenReturn(nuevoComentario);

        //ejecutamos el metodo del servicio a comprobar
        Comentario result = service.saveComentario(nuevoComentario);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoComentario); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getComentarios_returnsListOfComentarios() {
        List<Comentario> mockList = Arrays.asList(new Comentario(1L,"Comentario", new Date(0),"alta","publicacion de perritos","Los perritos son muy bonitos",1L,1L,1L));

        //configuramos la respuesta del repositorio
        when(repository.findAll()).thenReturn(mockList);

        //ejecutamos el metodo del servicio a comprobar
        List<Comentario> result = service.getComentarios();

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getComentario_returnsComentarioById() {
        //creamos un objeto de prueba para el select
        Comentario comentario = new Comentario(1L,"Comentario", new Date(0),"alta","publicacion de perritos","Los perritos son muy bonitos",1L,1L,1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(comentario));

        //ejecutamos el metodo del servicio a comprobar
        Comentario result = service.getComentarioById(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(comentario);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateComentario_returnsUpdatedComentario() {   
        //creamos un objeto de prueba para el update
        Comentario comentario1 = new Comentario(1L,"Comentario", new Date(0),"alta","publicacion de perritos","Los perritos son muy bonitos",1L,1L,1L);
        Comentario comentario2 = new Comentario(1L,"Comentario actualizado", new Date(0),"alta","publicacion de perritos","Los perritos son muy bonitos",1L,1L,1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(comentario1));
        when(repository.save(comentario1)).thenReturn(comentario1);

        //ejecutamos el metodo del servicio a comprobar
        Comentario result = service.updateComentario(1L, comentario2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(comentario1.getTitulo()).isEqualTo("Comentario actualizado");
        assertThat(result).isSameAs(comentario1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteComentario_deletesComentarioById() {
        //creamos un objeto de prueba para el delete
        Comentario comentario = new Comentario(1L,"Comentario", new Date(0),"alta","publicacion de perritos","Los perritos son muy bonitos",1L,1L,1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(comentario));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteComentario(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el comentario correcto
        assertThat(repository.findById(1L).isEmpty());

    }
}
