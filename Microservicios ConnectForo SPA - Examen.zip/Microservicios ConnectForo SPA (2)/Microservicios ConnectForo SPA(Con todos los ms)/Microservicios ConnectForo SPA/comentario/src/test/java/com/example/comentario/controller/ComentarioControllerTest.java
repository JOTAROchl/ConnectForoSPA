package com.example.comentario.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.comentario.model.Comentario;
import com.example.comentario.service.ComentarioService;
@WebMvcTest(ComentarioController.class)
public class ComentarioControllerTest {


    //inyectamos un mock de ReservaService para manipular nuestro contexto
    @MockBean
    private ComentarioService comentarioService;

    //se inyecta un mock proporcionado por spring para simular la llamada a la api
    @Autowired
    private MockMvc mockMvc;    


}
