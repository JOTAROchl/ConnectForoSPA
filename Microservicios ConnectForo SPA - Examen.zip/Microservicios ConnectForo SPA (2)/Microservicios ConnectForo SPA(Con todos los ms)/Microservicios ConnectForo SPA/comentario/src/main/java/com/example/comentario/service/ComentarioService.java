package com.example.comentario.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.comentario.WebClient.EstadoStatus;
import com.example.comentario.WebClient.PublicacionPublication;
import com.example.comentario.WebClient.UsuarioUser;
import com.example.comentario.model.Comentario;
import com.example.comentario.repository.ComentarioRepository;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ComentarioService {
    @Autowired
    private ComentarioRepository comentarioRepository;
    @Autowired
    private UsuarioUser usuarioUser;
    @Autowired
    private EstadoStatus estadoStatus;
    @Autowired 
    private PublicacionPublication publicacionPublication;

    @Schema(description = "Metodo para obtener todos los comentarios")
    public List<Comentario> getComentarios(){
        return comentarioRepository.findAll();
    }

    @Schema(description = "Metodo para obtener un comentario por su id")
    public Comentario getComentarioById(Long id){
        return comentarioRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Comentario no encontrado"));
    }

    @Schema(description = "Metodo para guardar un comentario")
    public Comentario saveComentario(Comentario comentario) {

        Map<String, Object> Estado = estadoStatus.obtenerEstadoId(comentario.getEstadoId());
        if (Estado == null || Estado.isEmpty()) {
            throw new RuntimeException("Estado no encontrado, no se puede agregar Comentario");
        }

        Map<String, Object> Usuario = usuarioUser.obtenerUsuarioId(comentario.getUsuarioId());
        if (Usuario == null || Usuario.isEmpty()) {
            throw new RuntimeException("Usuario no encontrado, no se puede agregar Comentario");
        }

        Map<String, Object> Publicacion = publicacionPublication.obtenerPublicacionId(comentario.getPublicacionId());
        if (Publicacion == null || Publicacion.isEmpty()) {
            throw new RuntimeException("Publicacion no encontrada, no se puede agregar Comentario");
        }

        return comentarioRepository.save(comentario);
    }

    @Schema(description = "Metodo para actulizar un comentario")
    public Comentario updateComentario(Long id, Comentario comentarioDetalle) {
        //verifica si el comentario existe
        Comentario comentario = comentarioRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Anuncio no encontrado"));
    
        //actualiza
        comentario.setTitulo(comentarioDetalle.getTitulo());
        comentario.setFecPublicacion(comentarioDetalle.getFecPublicacion());
        comentario.setDescripcion(comentarioDetalle.getDescripcion()); 
        comentario.setLugar(comentarioDetalle.getLugar());
        comentario.setPrioridad(comentarioDetalle.getPrioridad());
        comentario.setEstadoId(comentarioDetalle.getEstadoId());
        comentario.setUsuarioId(comentarioDetalle.getUsuarioId());
        comentario.setPublicacionId(comentarioDetalle.getPublicacionId());
        //guarda
        return comentarioRepository.save(comentario);
    }

    @Schema(description = "Metodo eliminar un comentario")
    public void deleteComentario(Long id){
        Comentario comentario = comentarioRepository.findById(id)
        //si no lo encuentra, se cancela
        .orElseThrow(() -> new RuntimeException("Comentario no encontrado"));
        //extermina el usuario
        comentarioRepository.delete(comentario);
    }

    @Schema(description = "Metodo para ver un historial de comentarios")
    public List<Comentario> getComentarioByUsuarioId(Long usuarioId) {
        return comentarioRepository.findAll().stream()
            .filter(comentario -> comentario.getUsuarioId().equals(usuarioId))
            .toList();
    }
}
