package com.example.comentario.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.comentario.model.Comentario;

@Repository
public interface ComentarioRepository extends JpaRepository <Comentario, Long>{

}
