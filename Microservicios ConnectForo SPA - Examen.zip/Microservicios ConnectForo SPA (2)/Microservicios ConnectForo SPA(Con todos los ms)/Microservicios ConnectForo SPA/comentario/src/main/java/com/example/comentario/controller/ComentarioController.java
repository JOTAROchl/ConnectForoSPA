package com.example.comentario.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.comentario.model.Comentario;
import com.example.comentario.service.ComentarioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/comentarios")
public class ComentarioController {
    @Autowired 
    private ComentarioService comentarioService;
    //EndPoints = EndP

    @Operation(summary = "EndPoint para encontrar todos los Comentarios")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos los Comentarios",
        content=@Content(schema=@Schema(implementation=Comentario.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Comentario registrado",
        content =@Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Comentario.class)))
    })
    @GetMapping
    public ResponseEntity<List<Comentario>> obtenerComentarios(){
        List<Comentario> comentarios = comentarioService.getComentarios();
        //si esta vacia = 204
        if (comentarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(comentarios);
    }

    @Operation(summary = "EndPoint para encontrar un solo Comentario mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró el Comentario por Id",
        content=@Content(schema=@Schema(implementation=Comentario.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Comentario.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Comentario> obtenerComentarioId(@PathVariable Long id){
        try {
            Comentario comentario = comentarioService.getComentarioById(id);
            return ResponseEntity.ok(comentario);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
            //si no existe = 404
        } 
    }

    @Operation(summary = "EndPoint para guardar un Comentario")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Comentario guardado exitosamente",
        content=@Content(schema=@Schema(implementation=Comentario.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Comentario.class)))
    })
    @PostMapping
    public ResponseEntity<Comentario> guardarComentario(@RequestBody Comentario comentario){
        return ResponseEntity.status(201).body(comentarioService.saveComentario(comentario));
    }

    @Operation(summary = "EndPoint para actualizar un Comentario y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Comentario actualizado exitosamente",
        content=@Content(schema=@Schema(implementation=Comentario.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="404", description="No se encontró el comentario",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Comentario.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Comentario> actualizarComentario(@PathVariable Long id, @RequestBody Comentario comentario){
        try {
            Comentario comentario2 = comentarioService.updateComentario(id, comentario);
            return ResponseEntity.ok(comentario2);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para eliminar un Comentario")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Comentario eliminado exitosamente",
        content=@Content(schema=@Schema(implementation=Comentario.class))),
        @ApiResponse(responseCode="404", description="No se encontró el comentario",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Comentario.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Comentario.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarComentario(@PathVariable Long id){
        try {
            comentarioService.deleteComentario(id);
            return ResponseEntity.noContent().build(); 
            //204 si fue correcto
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); 
            //404 si no existia
        }
    }


}
