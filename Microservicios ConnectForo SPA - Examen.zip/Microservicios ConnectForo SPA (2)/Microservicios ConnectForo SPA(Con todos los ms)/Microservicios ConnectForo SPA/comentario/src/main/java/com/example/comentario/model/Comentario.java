package com.example.comentario.model;

import java.util.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "comentarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Comentarios hechos en publicaciones por los usuarios")
public class Comentario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador unico de comentario")
    private Long id;

    @Column(nullable = false, length = 120)
    @Schema(description = "titulo del comentario")
    private String titulo;

    @Column(name = "fecha_publicacion", nullable = false)
    @Schema(description = "Fecha en que se hizo el comentario")
    private Date fecPublicacion;

    @Column(nullable = false, length = 30)
    @Schema(description = "Prioridad del comentario")
    private String prioridad;

    @Column(nullable = false, length = 50)
    @Schema(description = "Donde se hizo el comentario")
    private String lugar;

    @Column(nullable = false, length = 500)
    @Schema(description = "Lo que dice el comentario")
    private String descripcion;

    @Column(nullable = false)
    @Schema(description = "Estado actual del comentario")
    private Long estadoId;

    @Column(nullable = false)
    @Schema(description = "Quien hizo el comentario")
    private Long usuarioId;

    @Column(nullable = false)
    @Schema(description = "En cual publicacion se hizo el comentario")
    private Long publicacionId;
}
