package com.example.Usuario.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Usuario.model.Usuario;
import com.example.Usuario.repository.UsuarioRepository;
import com.example.Usuario.webclient.EstadoStatus;
import com.example.Usuario.webclient.RolRole;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRole rolRole;
    @Autowired
    private EstadoStatus estadoStatus;
    
    @Schema(description = "Metodo para obtener todos los Usuariosv")
    public List<Usuario> getUsuarios() {
        return usuarioRepository.findAll();
    }

    @Schema(description = "Metodo para obtener un solo Usuario por su Id")
    public Usuario getUsuarioId(Long id) {
        return usuarioRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Usuario no encontrado"));
    }

    @Schema(description = "Metodo para crear un Usuario")
    public Usuario saveUsuario(Usuario usuario) {
        //valida si existe el rol
        Map<String, Object> rol = rolRole.obtenerRolId(usuario.getRolId());
        
        if(rol == null || rol.isEmpty()) {
            throw new RuntimeException("Rol no encontrado, no se puede agregar usuario");
        }
        //valida si existe el estado
        Map<String, Object> Estado = estadoStatus.obtenerEstadoId(usuario.getEstadoId());
        if (Estado == null || Estado.isEmpty()) {
            throw new RuntimeException("Estado no encontrado, no se puede agregar usuario");
        }

        if (usuarioRepository.findByNombreUsuario(usuario.getNombreUsuario()).isPresent()) {
            throw new RuntimeException("********************** El nombre de usuario ya existe **********************");
        } else if (usuarioRepository.findByCorreo(usuario.getCorreo()).isPresent()) {
            throw new RuntimeException("********************** El correo ya esta en uso **********************");
        }

        return usuarioRepository.save(usuario);
    }

    @Schema(description = "Metodo para actualizar todos los datos de un Usuario")
    public Usuario updateUsuario(Long id, Usuario usuarioDetalle) {
        //verifica si el usuario existe
        Usuario usuario = usuarioRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Usuario no encontrado"));
    
        //actualiza
        usuario.setNombreUsuario(usuarioDetalle.getNombreUsuario());
        usuario.setClave(usuarioDetalle.getClave());
        usuario.setCorreo(usuarioDetalle.getCorreo());
        usuario.setRolId(usuarioDetalle.getRolId());
        usuario.setEstadoId(usuarioDetalle.getEstadoId());
        //guarda
        return usuarioRepository.save(usuario);
    }
    
    @Schema(description = "Metodo para eliminar un Usuario y todos sus datos")
    public void deleteUsuario(Long id){
        Usuario usuario = usuarioRepository.findById(id)
        //si no lo encuentra, se cancela
        .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        //extermina el usuario
        usuarioRepository.delete(usuario);
    }
    
    @Schema(description = "Metodo para encontrar un Usuario mediante su Rol")
    public Usuario getUsuarioRol(Long rolId){
        return usuarioRepository.findById(rolId)
        .orElseThrow(() -> new RuntimeException("Usuario con Rol no encontrado"));

    }
    @Schema(description = "Metodo para inicar sesion")
    public Usuario iniciarSesion(String nombreUsuario, String clave) {
        List<Usuario> usuarios = usuarioRepository.findAll();
        Usuario usuario = usuarios.stream()
            .filter(u -> u.getNombreUsuario().equals(nombreUsuario) && u.getClave().equals(clave))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Credenciales inválidas"));
        
        // Verifica si el estado del usuario es activo
        if (usuario.getEstadoId() != 1) { // Asumiendo que 1 es el ID del estado activo
            throw new RuntimeException("Usuario no activo");
        }
        
        return usuario;
    }



}
