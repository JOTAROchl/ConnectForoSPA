package com.example.Usuario.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description="Usuario de los Foros")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador unico del Usuario")
    private Long id;

    @Column(nullable = false, unique = true, length = 40)
    @Schema(description = "Nombre del Usuario")
    private String nombreUsuario;

    @Column(nullable = false, length = 100, unique = true)
    @Schema(description = "Correo electronico enlazado de la cuenta del Usuario")
    private String correo;

    @Column(nullable = false, length = 50)
    @Schema(description = "Clave de seguridad de la cuenta del Usuario")
    private String clave;

    @Column(nullable = false)
    @Schema(description = "El Rol que tiene el Usuario")
    private Long rolId;

    @Column(nullable = false)
    @Schema(description = "El estado de actual de la cuenta ")
    private Long estadoId;


}
