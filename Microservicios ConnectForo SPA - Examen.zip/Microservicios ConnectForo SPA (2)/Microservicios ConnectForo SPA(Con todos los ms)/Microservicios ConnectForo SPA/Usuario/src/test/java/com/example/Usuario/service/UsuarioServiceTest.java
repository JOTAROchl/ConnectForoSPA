package com.example.Usuario.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Usuario.model.Usuario;
import com.example.Usuario.repository.UsuarioRepository;
import com.example.Usuario.webclient.EstadoStatus;
import com.example.Usuario.webclient.RolRole;


@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {
    @Mock
    private UsuarioRepository repository;
    @Mock
    private RolRole rolRole;
    @Mock
    private EstadoStatus estadoStatus;
    @InjectMocks
    private UsuarioService service;

    @Test
    void saveUsuario_returnsSavedUsuario(){
        //creamos un objeto de prueba para el insert
        Usuario nuevoUsuario = new Usuario
        (1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);

        //configuramos la respuesta del repositorio
        // Mockea la respuesta de los webclients
        when(rolRole.obtenerRolId(1L)).thenReturn(Map.of("id", 1L, "nombreRol", "ADMIN"));
        when(estadoStatus.obtenerEstadoId(1L)).thenReturn(Map.of("id", 1L, "nombreEstado", "ACTIVO"));
        when(repository.save(nuevoUsuario)).thenReturn(nuevoUsuario);

        Usuario result = service.saveUsuario(nuevoUsuario);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoUsuario); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getUsuarios_returnsListOfUsuarios() {
        List<Usuario> mockList = List.of(new Usuario(1L, "Thomas", "th.ferra@duocuc.cl", "1234", 1L, 1L),
                                         new Usuario(2L, "Josue", "ju.urzua@duocuc.cl", "1234", 1L, 1L));
        when(repository.findAll()).thenReturn(mockList);
        List<Usuario> result = service.getUsuarios();
        assertThat(result).isEqualTo(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getUsuario_returnUsuarioById() {
        //creamos un objeto de prueba para el insert
        Usuario Usuario1 = new Usuario
        (1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(Usuario1));

        //ejecutamos el metodo del servicio a comprobar
        Usuario result = service.getUsuarioId(1L);

        //comprobamos que el resultado es el esperado
        assertThat(result).isSameAs(Usuario1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateUsuario_returnsUpdatedUsuario() {
        //creamos un objeto de prueba para el insert
        Usuario Usuario1 = new Usuario
        (1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);
        Usuario Usuario2 = new Usuario
        (2L,"Josue","ju.urzua@duocuc.cl","1234", 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(Usuario1));
        when(repository.save(Usuario1)).thenReturn(Usuario1);
        //ejecutamos el metodo del servicio a comprobar
        Usuario result = service.updateUsuario(1L, Usuario2);

        //comprobamos que el resultado es el esperado
        assertThat(Usuario1.getNombreUsuario()).isEqualTo("Josue");
        assertThat(result).isSameAs(Usuario1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteUsuario_returnsDeletedUsuario() {
        //creamos un objeto de prueba para el insert
        Usuario Usuario1 = new Usuario
        (1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);
        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(Usuario1));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteUsuario(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el usuario correcto
        assertThat(repository.findById(1L).isEmpty());
    }
}
