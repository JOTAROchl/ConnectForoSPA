package com.example.Usuario.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Usuario.model.Usuario;
import com.example.Usuario.service.UsuarioService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;


@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

    //inyectamos un mock de ReservaService para manipular nuestro contexto
    @MockBean
    private UsuarioService usuarioService;

    //se inyecta un mock proporcionado por spring para simular la llamada a la api
    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllUsuarios_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<Usuario> usuarios = Arrays.asList(new Usuario(1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L));

        //configuro el comportamiento del servicio simulado
        when(usuarioService.getUsuarios()).thenReturn(usuarios);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/usuarios"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id")
            .value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getUsuarioPorId_returnsOKAndJson() {
        //creamos una reserva de ejemplo
        Usuario usuario = new Usuario(1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(usuarioService.getUsuarioId(1L)).thenReturn(usuario);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/usuarios/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void saveUsuario_returnsCreatedAndJson() {
        //creamos una reserva de ejemplo
        Usuario usuario = new Usuario(1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(usuarioService.saveUsuario(usuario)).thenReturn(usuario);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201
        try {
            mockMvc.perform(post("/api/v1/usuarios")
            .contentType("application/json")
            .content("{\"id\":1,\"nombreUsuario\":\"Thomas\",\"correo\":\"th.ferra@duocuc.cl\",\"clave\":\"1234\",\"rolId\":1,\"estadoId\":1}"))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateUsuario_returnsOKAndJson() {
        //creamos una reserva de ejemplo
        Usuario usuario = new Usuario(1L,"Thomas","th.ferra@duocuc.cl","1234", 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(usuarioService.updateUsuario(1L, usuario)).thenReturn(usuario);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(put("/api/v1/usuarios/1")
            .contentType("application/json")
            .content("{\"id\":1,\"nombreUsuario\":\"Thomas\",\"correo\":\"th.ferra@duocuc.cl\",\"clave\":\"1234\",\"rolId\":1,\"estadoId\":1}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */

}
