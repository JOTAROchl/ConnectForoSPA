package com.example.Estado.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Estado.model.Estado;
import com.example.Estado.repository.EstadoRepository;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class EstadoService {
    @Autowired
    private EstadoRepository estadoRepository;

    @Schema(description = "Metodo para obtner todos los Estado")
    public List<Estado> getEstados() {
        return estadoRepository.findAll();
    }

    @Schema(description = "Metodo para obtener solo un Estado por su Id")
    public Estado getEstado(Long id){
        return estadoRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Estado no encontrado"));
    }

    @Schema(description = "Metodo para guardar un Estado")
    public Estado saveEstado(Estado estado){
        if (estadoRepository.findByNombreEstado(estado.getNombreEstado()).isPresent()) {
            throw new RuntimeException("********************** El Estado ya existe **********************");
        }
        return estadoRepository.save(estado);
    }

    @Schema(description = "Metodo para actualizar un Estado y sus Datos")
    public Estado updateEstado(Long id, Estado estado){
        Estado estado2 = estadoRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Estado no encontrado"));
        //actualizando
        estado2.setNombreEstado(estado.getNombreEstado());
        //guardando
        return estadoRepository.save(estado2);
    }

    @Schema(description = "Metodo para elimanar un Estado")
    public void deleteEstado(Long id){
        Estado estado = estadoRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Estado no encontrado"));
        estadoRepository.delete(estado);
    }
}
