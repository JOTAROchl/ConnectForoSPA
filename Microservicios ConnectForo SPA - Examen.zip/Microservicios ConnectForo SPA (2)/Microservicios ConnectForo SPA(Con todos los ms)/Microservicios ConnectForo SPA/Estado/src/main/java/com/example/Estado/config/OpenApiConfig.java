package com.example.Estado.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.OpenAPI;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI apiInfo(){
        return new OpenAPI()
        .info(new Info()
            .title("Estados de ConnectForoSPA")
            .version("1.0")
            .description("Estados de los diferentes elementos de ConnectForoSPA"));
    }
        
}
