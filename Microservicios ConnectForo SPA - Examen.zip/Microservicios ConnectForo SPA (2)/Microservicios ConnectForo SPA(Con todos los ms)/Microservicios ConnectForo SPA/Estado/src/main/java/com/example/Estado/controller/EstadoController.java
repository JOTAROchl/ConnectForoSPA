package com.example.Estado.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Estado.model.Estado;
import com.example.Estado.service.EstadoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/estados")
public class EstadoController {
    @Autowired
    private EstadoService estadoService;


    @Operation(summary = "EndPoint para encontrar todos los Estados")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos los Estados",
        content=@Content(schema=@Schema(implementation=Estado.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Estado registrado",
        content =@Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Estado.class)))
    })
    @GetMapping
    public ResponseEntity<List<Estado>> obtenerEstados(){
        List<Estado> estados = estadoService.getEstados();
        if (estados.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(estados);
    }

    @Operation(summary = "EndPoint para encontrar un Estado por su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Estado encontrado",
        content=@Content(schema=@Schema(implementation=Estado.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Estado.class)))
    })
    @GetMapping({"/{id}"})
    public ResponseEntity<Estado> obtenerEstadoId(@PathVariable Long id){
        try{
            Estado estado =  estadoService.getEstado(id);
            return ResponseEntity.ok(estado);

        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para guardar un Estado")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Estado creado",
        content=@Content(schema=@Schema(implementation=Estado.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Estado.class)))
    })
    @PostMapping
    public ResponseEntity<Estado> guardarEstado(@RequestBody Estado estado){
        return ResponseEntity.status(201).body(estadoService.saveEstado(estado));
    }

    @Operation(summary = "EndPoint para actualizar un Estado y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Estado actualizado exitosamente",
        content=@Content(schema=@Schema(implementation=Estado.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="404", description="No se encontró el estado",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Estado.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Estado> actualizarEstado(@PathVariable Long id, @RequestBody Estado estado){
        try{
            Estado estado2 = estadoService.updateEstado(id, estado);
            return ResponseEntity.ok(estado2);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para eliminar un Estado")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Estado eliminado exitosamente",
        content=@Content(schema=@Schema(implementation=Estado.class))),
        @ApiResponse(responseCode="404", description="No se encontró el estado",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Estado.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Estado.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEstado(@PathVariable Long id){
        try {
            estadoService.deleteEstado(id);
                return ResponseEntity.noContent().build();
                // 204 si esta bien    
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
            // 404 si no existe
        }
    }



}
