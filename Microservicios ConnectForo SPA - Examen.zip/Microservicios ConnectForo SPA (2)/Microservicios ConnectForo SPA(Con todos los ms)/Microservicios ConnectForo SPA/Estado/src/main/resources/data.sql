insert into estados (nombre_estado) values ('Active');
insert into estados (nombre_estado) values ('Inactive');