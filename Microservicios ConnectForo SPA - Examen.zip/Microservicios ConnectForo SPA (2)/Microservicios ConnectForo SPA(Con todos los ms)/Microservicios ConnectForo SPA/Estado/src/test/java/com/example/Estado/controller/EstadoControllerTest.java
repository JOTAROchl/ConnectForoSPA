package com.example.Estado.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Estado.model.Estado;
import com.example.Estado.service.EstadoService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

@WebMvcTest(EstadoController.class)
public class EstadoControllerTest {

    //inyectamos un mock de EstadoService para manipular nuestro contexto
    @MockBean
    private EstadoService estadoService;

    //se inyecta un mock proporcionado por spring para simular la llamada a la api
    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllEstados_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<Estado> estados = Arrays.asList(new Estado(1L,"Active"));

        //configuro el comportamiento del servicio simulado
        when(estadoService.getEstados()).thenReturn(estados);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/estados"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id")
            .value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getEstadoPorId_returnsOKAndJson() {
        //creamos una reserva de ejemplo
        Estado estado = new Estado(1L,"Activo");

        //configuro el comportamiento del servicio simulado
        when(estadoService.getEstado(1L)).thenReturn(estado);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/estados/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void saveEstado_returnsCreatedAndJson() {
        //creamos una reserva de ejemplo
        Estado estado = new Estado(1L,"Activo");

        //configuro el comportamiento del servicio simulado
        when(estadoService.saveEstado(estado)).thenReturn(estado);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201
        try {
            mockMvc.perform(post("/api/v1/estados")
            .contentType("application/json")
            .content("{\"id\":1,\"nombreEstado\":\"Activo\"}"))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateEstado_returnsUpdatedEstado() {
        //creamos un objeto de prueba para el update
        Estado estado = new Estado(1L,"Activo");

        //configuramos la respuesta del servicio simulado
        when(estadoService.updateEstado(1L, estado)).thenReturn(estado);

        //ejecutamos el metodo del servicio a comprobar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200
        
        try {
            mockMvc.perform(put("/api/v1/estados/1")
            .contentType("application/json")
            .content("{\"id\":1,\"nombreEstado\":\"Activo\"}"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
}

