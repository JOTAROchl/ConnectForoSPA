package com.example.Estado.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Estado.model.Estado;
import com.example.Estado.repository.EstadoRepository;

@ExtendWith(MockitoExtension.class)
public class EstadoServiceTest {
    @Mock
    private EstadoRepository repository;

    @InjectMocks
    private EstadoService service;

    @Test
    void save_returnsSavedEstado(){
        //creamos un objeto de prueba para el insert
        Estado nuevoEstado = new Estado(1L,"Activo");

        //configuramos la respuesta del repositorio
        when(repository.save(nuevoEstado)).thenReturn(nuevoEstado);

        //ejecutamos el metodo del servicio a comprobar
        Estado result = service.saveEstado(nuevoEstado);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoEstado); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getEstados_returnsEstadoById(){
        List<Estado> mockList = Arrays.asList(
            new Estado(1L, "Activo"), new Estado(2L, "Inactivo"));
        when(repository.findAll()).thenReturn(mockList);
        List<Estado> result = service.getEstados();
        assertThat(result).isEqualTo(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getEstado_returnsEstadoById(){
        //creamos un objeto de prueba para el select
        Estado estado = new Estado(1L,"Active");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(estado));

        //ejecutamos el metodo del servicio a comprobar
        Estado result = service.getEstado(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(estado); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateEstado_returnsUpdatedEstado(){
        //creamos un objeto de prueba para el update
        Estado estado1 = new Estado(1L,"Estado");
        Estado estado2 = new Estado(1L,"Estado2");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(estado1));
        when(repository.save(estado2)).thenReturn(estado2);

        //ejecutamos el metodo del servicio a comprobar
        Estado result = service.updateEstado(1L, estado2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(estado1.getNombreEstado()).isEqualTo("Estado2");
        assertThat(result).isSameAs(estado2); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteEstado_deletesEstadoById(){
        //creamos un objeto de prueba para el delete
        Estado estado = new Estado(1L,"Active");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(estado));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteEstado(1L);

        //comprobamos que el repositorio haya sido llamado para eliminar el estado
        assertThat(repository.findById(1L).isEmpty());
    }
}
