package com.example.Rol.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Rol.model.Rol;
import com.example.Rol.service.RolService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

//cargamos el controlador que vamos a probar
@WebMvcTest(RolController.class)
public class RolControllerTest {

    //inyectamos un mock de ReservaService para manipular nuestro contexto
    @MockBean
    private RolService rolService;

    //se inyecta un mock proporcionado por spring para simular la llamada a la api
    private MockMvc mockMvc;

    @Test
    void getRoles_returnsOkAndJson(){
        //creamos un rol de ejemplo
        List<Rol> rols = Arrays.asList(new Rol(1L,"Administrador"));

        //configuro el comportamiento del servicio simulado
        when(rolService.getRoles()).thenReturn(rols);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/roles"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getRol_returnsOkAndJson() {
        //creamos un rol de ejemplo
        Rol rol = new Rol(1L, "Administrador");

        //configuro el comportamiento del servicio simulado
        when(rolService.getRol(1L)).thenReturn(rol);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/roles/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */

    @Test
    void saveRol_returnsCreatedAndJson() {
        //creamos un rol de ejemplo
        Rol rol = new Rol(1L, "Administrador");

        //configuro el comportamiento del servicio simulado
        when(rolService.saveRol(rol)).thenReturn(rol);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201

        try {
            mockMvc.perform(post("api/v1/roles")
                    .contentType("application/json")
                    .content("{\"id\":1,\"nombreRol\":\"Administrador\"}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id")
                    .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }   

    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateRol_returnsUpdatedRol() {
        //creamos un rol de ejemplo
        Rol rol = new Rol(1L, "Administrador");

        //configuro el comportamiento del servicio simulado
        when(rolService.updateRol(1L, rol)).thenReturn(rol);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(put("api/v1/roles/1")
                    .contentType("application/json")
                    .content("{\"id\":1,\"nombreRol\":\"Administrador\"}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */

    /* 
    @Test
    void deleteRol_returnsNoContent() {
        //configuro el comportamiento del servicio simulado
        // configuro el comportamiento del servicio simulado
        // si deleteRol retorna boolean, puedes dejarlo así:
        org.mockito.Mockito.doReturn(true).when(rolService).deleteRol(1L);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo delete con la url
        //verificar que retorna el codigo 204

        try {
            mockMvc.perform(delete("api/v1/roles/1"))
                    .andExpect(status().isNoContent());
        } catch (Exception e) {
            e.printStackTrace();
        }
    } */
}