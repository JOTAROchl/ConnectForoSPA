package com.example.Rol.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Rol.model.Rol;
import com.example.Rol.repository.RolRepository;

@ExtendWith(MockitoExtension.class)
public class RolServiceTest {
    @Mock
    private RolRepository repository;

    @InjectMocks
    private RolService service;

    @Test
    void save_returnsSavedRol(){
        //creamos un objeto de prueba para el insert
        Rol nuevoRol = new Rol(1L,"Administrador");

        //configuramos la respuesta del repositorio
        when(repository.save(nuevoRol)).thenReturn(nuevoRol);

        //ejecutamos el metodo del servicio a comprobar
        Rol result = service.saveRol(nuevoRol);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoRol);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getRoles_returnsListOfRoles() {
        List<Rol> mockList = Arrays.asList(new Rol(1L, "Usuario"));

        //configuramos la respuesta del repositorio
        when(repository.findAll()).thenReturn(mockList);

        //ejecutamos el metodo del servicio a comprobar
        List<Rol> result = service.getRoles();

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getRol_returnsRolById() {
        //creamos un objeto de prueba para el select
        Rol rol = new Rol(1L, "Usuario");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(rol));

        //ejecutamos el metodo del servicio a comprobar
        Rol result = service.getRol(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(rol);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateRol_returnsUpdatedRol() {   
        //creamos un objeto de prueba para el update
        Rol rol1 = new Rol(1L, "Usuario");
        Rol rol2 = new Rol(1L, "Usuario2");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(rol1));
        when(repository.save(rol1)).thenReturn(rol1);

        //ejecutamos el metodo del servicio a comprobar
        Rol result = service.updateRol(1L, rol2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(rol1.getNombreRol()).isEqualTo("Usuario2");
        assertThat(result).isSameAs(rol1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteRol_deletesRolById() {
        //creamos un objeto de prueba para el delete
        Rol rol = new Rol(1L, "Usuario");

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(rol));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteRol(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el rol correcto
        assertThat(repository.findById(1L).isEmpty());

    }
}
