package com.example.Rol.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.Rol.model.Rol;
import com.example.Rol.service.RolService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
@RequestMapping("/api/v1/roles")
public class RolController {
    @Autowired
    private RolService rolService;

    @Operation(summary = "EndPoint para encontrar todos los Roles")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos los Roles",
        content=@Content(schema=@Schema(implementation=Rol.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Rol registrado",
        content =@Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Rol.class)))
    })
    @GetMapping
    public ResponseEntity<List<Rol>> obtenerRoles() {
        List<Rol> roles = rolService.getRoles();
        if(roles.isEmpty()){ //verifica si 
            //la lista de roles esta vacia
            return ResponseEntity.noContent().build();
            //vacia = 204
        }
        return ResponseEntity.ok(roles);
    }

    @Operation(summary = "EndPoint para encontrar un solo Rol mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró el Rol por Id",
        content=@Content(schema=@Schema(implementation=Rol.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Rol.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Rol> obtenerRolPorId(@PathVariable Long id) {
            try{
                Rol rol = rolService.getRol(id);
                return ResponseEntity.ok(rol);
            } catch (Exception e){
                return ResponseEntity.notFound().build();
                //si no lo encuentra = 404
            }
    }

    @Operation(summary = "EndPoint para guardar un Rol")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Rol guardado exitosamente",
        content=@Content(schema=@Schema(implementation=Rol.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Rol.class)))
    })
    @PostMapping
    public ResponseEntity<Rol> guardarRol(@RequestBody Rol rol) {
        return ResponseEntity.status(201).body(rolService.saveRol(rol));
    }

    @Operation(summary = "EndPoint para actualizar un Rol y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Rol actualizado exitosamente",
        content=@Content(schema=@Schema(implementation=Rol.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="404", description="No se encontró el rol",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Rol.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Rol> actualizarRolId(@PathVariable Long id, @RequestBody Rol rol){
        try {
            Rol rolActualizado = rolService.updateRol(id, rol);
            return ResponseEntity.ok(rolActualizado);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        } 
    }

    @Operation(summary = "EndPoint para eliminar un Rol")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Rol eliminado exitosamente",
        content=@Content(schema=@Schema(implementation=Rol.class))),
        @ApiResponse(responseCode="404", description="No se encontró el rol",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Rol.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Rol.class)))
    })
    @Schema(description = "EndPoint para eliminar un Rol")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRol(@PathVariable Long id) {
        try {
            rolService.deleteRol(id);
            return ResponseEntity.noContent().build(); 
            //genera error 204 si fue correcto
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); 
            //404 si no existe
        }
    }



}
