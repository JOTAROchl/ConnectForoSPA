package com.example.Rol.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Rol.model.Rol;
import com.example.Rol.repository.RolRepository;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class RolService {
    @Autowired
    private RolRepository rolRepository;

    @Schema(description = "Metodo para obtener todos los Roles")
    public List<Rol> getRoles(){
        return rolRepository.findAll();
    }

    @Schema(description = "Metodo para obterner un solo Rol por su Id")
    public Rol getRol(Long id){
        return rolRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Rol no encontrado"));
    }

    @Schema(description = "Metodo para guardar un Rol")
    public Rol saveRol (Rol rol){
        if (rolRepository.findByNombreRol(rol.getNombreRol()).isPresent()) {
            throw new IllegalArgumentException("********************** El rol ya existe **********************");
        }
        return rolRepository.save(rol);
    }

    @Schema(description = "Metodo para actualizar un Rol y todos sus Datos")
    public Rol updateRol(Long id, Rol rolDetails){
        Rol rol = rolRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Rol no encontrado"));
        //actualiza
        rol.setNombreRol(rolDetails.getNombreRol()); 
        //guarda
        return rolRepository.save(rol);
    }

    @Schema(description = "Metodo para eliminar un Rol")
    public void deleteRol(Long id){
        Rol rol = rolRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Rol no encontrado"));
        rolRepository.delete(rol);
    }
}
