insert into roles (nombre_rol) values ('ROLE_ADMIN');
insert into roles (nombre_rol) values ('ROLE_MODERATOR');
insert into roles (nombre_rol) values ('ROLE_TECH_SUPPORT');
insert into roles (nombre_rol) values ('ROLE_ANOUNCEMENT_MANAGER');
insert into roles (nombre_rol) values ('ROLE_USER');