package com.example.Repote.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Repote.model.Reporte;
import com.example.Repote.service.ReporteService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/reportes")
public class ReporteController {
    @Autowired 
    private ReporteService reporteService;
    //EndPoints = EndP

    //EndP para todos reportes
    @Operation(summary = "EndPoint para encontrar todos los Reportes")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos los Reportes",
        content=@Content(schema=@Schema(implementation=Reporte.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Reporte registrado",
        content =@Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Reporte.class)))
    })
    @GetMapping
    public ResponseEntity<List<Reporte>> obtenerReportes(){
        List<Reporte> reportes = reporteService.getReportes();
        if(reportes.isEmpty()){
            //si esta vacia = 204
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(reportes);
    }

    //EndP para reporte id
    @Operation(summary = "EndPoint para encontrar un solo Reporte mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró el Reporte por Id",
        content=@Content(schema=@Schema(implementation=Reporte.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Reporte.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Reporte> obtenerReporteId(@PathVariable Long id){
        try {
            Reporte reporte = reporteService.getReporte(id);
            return ResponseEntity.ok(reporte);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
            //si no existe = 404
        } 
    }

    //EndP para guardar 
    @Operation(summary = "EndPoint para guardar un Reporte")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Reporte guardado exitosamente",
        content=@Content(schema=@Schema(implementation=Reporte.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Reporte.class)))
    })
    @PostMapping
    public ResponseEntity<Reporte> guardarReporte(@RequestBody Reporte reporte){
        return ResponseEntity.status(201).body(reporteService.saveReporte(reporte));
    }

    //EndP para actualizar 
    @Operation(summary = "EndPoint para actualizar un Reporte y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Reporte actualizado exitosamente",
        content=@Content(schema=@Schema(implementation=Reporte.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="404", description="No se encontró el reporte",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Reporte.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Reporte> actualizarReporte(@PathVariable Long id, @RequestBody Reporte reporte){
        try {
            Reporte reporte2 = reporteService.updateReporte(id, reporte);
            return ResponseEntity.ok(reporte2);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    //EndP para eliminar 
    @Operation(summary = "EndPoint para eliminar un Reporte")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Reporte eliminado exitosamente",
        content=@Content(schema=@Schema(implementation=Reporte.class))),
        @ApiResponse(responseCode="404", description="No se encontró el reporte",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Reporte.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Reporte.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarReporte(@PathVariable Long id){
        try {
            reporteService.deleteReporte(id);
            return ResponseEntity.noContent().build(); 
            //204 si fue correcto
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); 
            //404 si no existia
        }
    }

}
