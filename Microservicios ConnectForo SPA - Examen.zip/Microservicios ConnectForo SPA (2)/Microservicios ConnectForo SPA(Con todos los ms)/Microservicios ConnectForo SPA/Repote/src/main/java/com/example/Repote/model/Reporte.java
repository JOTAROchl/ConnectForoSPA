package com.example.Repote.model;

import java.sql.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "reporte")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Reportes que hacen los Usuarios cuando alguien no cumple con las normativas de uso de la aplicacion")
public class Reporte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador unico de Reporte")
    private Long id;

    @Column(name = "fecha_reporte", nullable = false)
    @Schema(description = "Fecha en que se hizo el Reporte")
    private Date fecReporte;

    @Column(nullable = false, length = 30)
    @Schema(description = "El tipo de Elemento que se Reporta")
    private String tipoElemento;

    @Column(nullable = false, length = 500)
    @Schema(description = "El motivo por el cual se Reporto")
    private String motivo;

    @Column(nullable = true, length = 500)
    @Schema(description = "Respuesta de los moderadores al Reporte")
    private String respuesta;

    @Column(nullable = true, length = 300)
    @Schema(description = "Descripcion de lo que se va hacer en contra de elemento Reportado")
    private String accion;

    @Column(name = "fecha_accion", nullable = true)
    @Schema(description = "Fecha en que se hace la accion en contra del elemento Reportado")
    private Date fecAccion;

    @Column(nullable = false)
    @Schema(description = "Usuario Reportado")
    private Long usuarioId; //usuario reportado

    @Column(nullable = false)
    @Schema(description = "Estado del Reporte")
    private Long estadoId;
}
