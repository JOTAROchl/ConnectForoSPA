package com.example.Repote.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Repote.model.Reporte;

@Repository
public interface ReporteRepository extends JpaRepository <Reporte, Long>{

}
