package com.example.Repote.service;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.sql.Date;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Repote.model.Reporte;
import com.example.Repote.repository.ReporteRepository;
import com.example.Repote.webclient.EstadoStatus;
import com.example.Repote.webclient.UsuarioUser;

@ExtendWith(MockitoExtension.class)
public class ReporteServiceTest {
    @Mock
    private ReporteRepository repository;
    @Mock
    private UsuarioUser usuarioUser;
    @Mock
    private EstadoStatus estadoStatus;

    @InjectMocks
    private ReporteService service;

    @Test
    void saveReporte_returnsSavedReporte(){
        //creamos un objeto de prueba para el insert
        Reporte nuevoreReporte = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);
        //configuramos la respuesta del repositorio
        

        when(usuarioUser.obtenerUsuarioId(1L))
        .thenReturn(Map.of("id", 1L, "nombreUsuario","Thomas","correo","th.ferra@duocuc.cl","clave","1234","rolId",1L,"estadoId",1L));
        when(estadoStatus.obtenerEstadoId(1L)).thenReturn(Map.of("id", 1L, "nombreEstado", "ACTIVO"));
        when(repository.save(nuevoreReporte)).thenReturn(nuevoreReporte);

        //ejecutamos el metodo del servicio a comprobar
        Reporte result = service.saveReporte(nuevoreReporte);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoreReporte); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getReportes_returnsListOfReportes() {
        List<Reporte> mockList = Arrays.asList(new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L));

        //configuramos la respuesta del repositorio
        when(repository.findAll()).thenReturn(mockList);

        //ejecutamos el metodo del servicio a comprobar
        List<Reporte> result = service.getReportes();

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getReporte_returnsReporteById() {
        //creamos un objeto de prueba para el select
        Reporte reporte = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(reporte));

        //ejecutamos el metodo del servicio a comprobar
        Reporte result = service.getReporte(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(reporte);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateReporte_returnsUpdatedReporte() {   
        //creamos un objeto de prueba para el update
        Reporte reporte1 = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);
        Reporte reporte2 = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(reporte1));
        when(repository.save(reporte1)).thenReturn(reporte1);

        //ejecutamos el metodo del servicio a comprobar
        Reporte result = service.updateReporte(1L, reporte2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(reporte1.getTipoElemento()).isEqualTo("Comentario");
        assertThat(result).isSameAs(reporte1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteReporte_deletesReporteById() {
        //creamos un objeto de prueba para el delete
        Reporte reporte = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(reporte));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteReporte(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el rol correcto
        assertThat(repository.findById(1L).isEmpty());

    }
}
