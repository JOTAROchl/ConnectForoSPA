package com.example.Repote.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Repote.model.Reporte;
import com.example.Repote.service.ReporteService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;



@WebMvcTest(ReporteController.class)
public class ReporteControllerTest {

    @MockBean
    private ReporteService reporteService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getReporte_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<Reporte> reportes = Arrays.asList(new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L));

        //configuro el comportamiento del servicio simulado
        when(reporteService.getReportes()).thenReturn(reportes);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/reportes")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getReporte_returnsOkAndJson() {
        //creamos un reporte de ejemplo
        Reporte reporte = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(reporteService.getReporte(1L)).thenReturn(reporte);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/reportes/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void saveReporte_returnsCreatedAndJson() {
        //creamos un reporte de ejemplo
        Reporte reporte = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(reporteService.saveReporte(reporte)).thenReturn(reporte);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201

        try {
            mockMvc.perform(post("api/v1/reportes")
                    .contentType("application/json")
                    .content("{\"id\":1,\"fecha\":\"1970-01-01\",\"tipoElemento\":\"Comentario\",\"motivo\":\"Racista\",\"respuesta\":null,\"accion\":null,\"fecAccion\":null,\"estadoId\":1,\"usuarioId\":1}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id")
                    .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }   
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateReport_returnsUpdatedReporte() {
        //creamos un reporte de ejemplo
        Reporte reporte = new Reporte(1L, new Date(0), "Comentario", "Racista", null, null, null, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(reporteService.updateReporte(1L, reporte)).thenReturn(reporte);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(put("api/v1/reportes/1")
                    .contentType("application/json")
                    .content("{\"id\":1,\"fecha\":\"1970-01-01\",\"tipoElemento\":\"Comentario\",\"motivo\":\"Racista\",\"respuesta\":null,\"accion\":null,\"fecAccion\":null,\"estadoId\":1,\"usuarioId\":1}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */


}
