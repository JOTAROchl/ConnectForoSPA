package com.example.Anuncio.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.Map;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Anuncio.model.Anuncio;
import com.example.Anuncio.repository.AnuncioRepository;
import com.example.Anuncio.webclient.EstadoStatus;
import com.example.Anuncio.webclient.UsuarioUser;

@ExtendWith(MockitoExtension.class)
public class AnuncioServiceTest {
    @Mock
    private AnuncioRepository repository;
    @Mock
    private UsuarioUser usuarioUser;
    @Mock
    private EstadoStatus estadoStatus;

    @InjectMocks
    private AnuncioService service;

    @Test
    void saveAnuncio_returnsSavedAnuncio(){
     //creamos un objeto de prueba para el insert
        Anuncio nuevoAnuncio = new Anuncio
        (1L, "Bienvenido", new Date(0), "Alta", "Foro", "Bienvenidos a todos", 1L, 1L);
        //configuramos la respuesta del repositorio

        when(estadoStatus.obtenerEstadoId(1L)).thenReturn(Map.of("id", 1L, "nombreEstado", "ACTIVO"));
        when(usuarioUser.obtenerUsuarioId(1L)).thenReturn(Map.of("id", 1L, "nombreUsuario","Thomas","correo","th.ferra@duocuc.cl","clave","1234","rolId",1L,"estadoId",1L));
        when(repository.save(nuevoAnuncio)).thenReturn(nuevoAnuncio);

        //ejecutamos el metodo del servicio a comprobar
        Anuncio result = service.saveAnuncio(nuevoAnuncio);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoAnuncio); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getAnuncios_returnsListOfAnuncios(){
        //configuramos el repositorio
        List<Anuncio> anuncios = Arrays.asList(
                            new Anuncio(1L, "Anuncio 1", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L),
                            new Anuncio(2L, "Anuncio 2", new Date(0), "Baja", "Foro", "Contenido 2", 2L, 2L));
        
        when(repository.findAll()).thenReturn(anuncios);
        List<Anuncio> result = service.getAnuncios();
        assertThat(result).isEqualTo(anuncios);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getAnuncio_returnsAnuncioById() {
        //creamos un objeto de prueba para el select
        Anuncio anuncio = new Anuncio(1L, "Anuncio 1", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(anuncio));

        //ejecutamos el metodo del servicio a comprobar
        Anuncio result = service.getAnuncio(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(anuncio);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateAnuncio_returnsUpdatedAnuncio() {   
        //creamos un objeto de prueba para el update
        Anuncio anuncio1 = new Anuncio(1L, "Anuncio 1", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L);
        Anuncio anuncio2 = new Anuncio(1L, "Anuncio 2", new Date(0), "Baja", "Foro", "Contenido 2", 2L, 2L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(anuncio1));
        when(repository.save(anuncio1)).thenReturn(anuncio1);

        //ejecutamos el metodo del servicio a comprobar
        Anuncio result = service.updateAnuncio(1L, anuncio2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(anuncio1.getTitulo()).isEqualTo("Anuncio 2");
        assertThat(result).isSameAs(anuncio1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteAnuncio_deletesAnuncioById() {
        //creamos un objeto de prueba para el delete
        Anuncio anuncio = new Anuncio(1L, "Anuncio 1", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(anuncio));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteAnuncio(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el anuncio correcto
        assertThat(repository.findById(1L).isEmpty());

    }

}
