package com.example.Anuncio.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Anuncio.model.Anuncio;
import com.example.Anuncio.service.AnuncioService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

@WebMvcTest(AnuncioController.class)
public class AnuncioControllerTest {

    @MockBean
    private AnuncioService anuncioService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAnuncios_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<Anuncio> anuncios = Arrays.asList(new Anuncio(1L, "Anuncio", new Date(0), "Alta", "Foro", "Bienvenidos a todos", 1L, 1L));

        //configuro el comportamiento del servicio simulado
        when(anuncioService.getAnuncios()).thenReturn(anuncios);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/anuncios")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getAnuncio_returnsOkAndJson() {
        //creamos un anuncio de ejemplo
        Anuncio anuncio = new Anuncio(1L, "Anuncio", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(anuncioService.getAnuncio(1L)).thenReturn(anuncio);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/anuncios/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void saveAnuncio_returnsCreatedAndJson() {
        //creamos un anuncio de ejemplo
        Anuncio anuncio = new Anuncio(1L, "Anuncio", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(anuncioService.saveAnuncio(anuncio)).thenReturn(anuncio);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201

        try {
            mockMvc.perform(post("api/v1/anuncios")
                    .contentType("application/json")
                    .content("{\"id\":1,\"titulo\":\"Anuncio\",\"fecha\":\"2023-01-01\",\"prioridad\":\"Alta\",\"lugar\":\"Foro\",\"descripcion\":\"Contenido 1\",\"estadoId\":1,\"usuarioId\":1}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id")
                    .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }   
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateAnuncio_returnsUpdatedAnuncio() {
        //creamos un anuncio de ejemplo
        Anuncio anuncio = new Anuncio(1L, "Anuncio", new Date(0), "Alta", "Foro", "Contenido 1", 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(anuncioService.updateAnuncio(1L, anuncio)).thenReturn(anuncio);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(put("api/v1/anuncios/1")
                    .contentType("application/json")
                    .content("{\"id\":1,\"titulo\":\"Anuncio\",\"fecha\":\"2023-01-01\",\"prioridad\":\"Alta\",\"lugar\":\"Foro\",\"descripcion\":\"Contenido 1\",\"estadoId\":1,\"usuarioId\":1}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    
}
