package com.example.Anuncio.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Anuncio.model.Anuncio;
import com.example.Anuncio.repository.AnuncioRepository;
import com.example.Anuncio.webclient.EstadoStatus;
import com.example.Anuncio.webclient.UsuarioUser;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class AnuncioService {
    @Autowired
    private AnuncioRepository anuncioRepository;
    @Autowired
    private UsuarioUser usuarioUser;
    @Autowired
    private EstadoStatus estadoStatus;

    @Schema(description = "Metodo para obtener todos los Anuncios")
    public List<Anuncio> getAnuncios(){
        return anuncioRepository.findAll();
    }

    @Schema(description = "Metodo para obtener un solo anuncio por su Id")
    public Anuncio getAnuncio(Long id){
        return anuncioRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Anuncio no encontrado"));
    }

    @Schema(description = "Metodo para guardar anuncios")
    public Anuncio saveAnuncio(Anuncio anuncio) {
        //valida si existe el estado
        Map<String, Object> Estado = estadoStatus.obtenerEstadoId(anuncio.getEstadoId());
        if (Estado == null || Estado.isEmpty()) {
            throw new RuntimeException("Estado no encontrado, no se puede agregar anuncio");
        }
        //valida si existe el usuario
        Map<String, Object> Usuario = usuarioUser.obtenerUsuarioId(anuncio.getUsuarioId());
        if (Usuario == null || Usuario.isEmpty()) {
            throw new RuntimeException("Usuario no encontrado, no se puede agregar anuncio");
        }

        return anuncioRepository.save(anuncio);
    }
    
    @Schema(description = "Metodo para actualizar un anuncio y sus datos")
    public Anuncio updateAnuncio(Long id, Anuncio anuncioDetalle) {
        //verifica si el usuario existe
        Anuncio anuncio = anuncioRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Anuncio no encontrado"));
    
        //actualiza
        anuncio.setTitulo(anuncioDetalle.getTitulo());
        anuncio.setFecPublicacion(anuncioDetalle.getFecPublicacion());
        anuncio.setDescripcion(anuncioDetalle.getDescripcion()); 
        anuncio.setLugar(anuncioDetalle.getLugar());
        anuncio.setPrioridad(anuncioDetalle.getPrioridad());
        anuncio.setEstadoId(anuncioDetalle.getEstadoId());
        anuncio.setUsuarioId(anuncioDetalle.getUsuarioId());
        //guarda
        return anuncioRepository.save(anuncio);
    }

    @Schema(description = "Metodo para elminar un anuncio")
    public void deleteAnuncio(Long id){
        Anuncio anuncio = anuncioRepository.findById(id)
        //si no lo encuentra, se cancela
        .orElseThrow(() -> new RuntimeException("Anuncio no encontrado"));
        //extermina el usuario
        anuncioRepository.delete(anuncio);
    }

}
