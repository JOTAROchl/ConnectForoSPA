package com.example.Anuncio.model;

import java.sql.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "anuncios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Anuncios que se le dan a los Usuario")
public class Anuncio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador unico de Anuncio")
    private Long id;

    @Column(nullable = false, length = 120)
    @Schema(description = "Titulo de anuncio")
    private String titulo;

    @Column(name = "fecha_publicacion", nullable = false)
    @Schema(description = "Fecha en que se publico el anuncion")
    private Date fecPublicacion;

    @Column(nullable = false, length = 30)
    @Schema(description = "Señala la importancia del anuncio")
    private String prioridad;

    @Column(nullable = false, length = 50)
    @Schema(description = "Donde fue el anuncio dado")
    private String lugar;

    @Column(nullable = false, length = 500)
    @Schema(description = "Descripcion o datos adicionales del anuncio")
    private String descripcion;

    @Column(nullable = false)
    @Schema(description = "Estado del anuncio")
    private Long estadoId;

    @Column(nullable = false)
    @Schema(description = "Usuario que hizo el anuncio")
    private Long usuarioId;
}
