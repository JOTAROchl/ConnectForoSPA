package com.example.Anuncio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Anuncio.model.Anuncio;
import com.example.Anuncio.service.AnuncioService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/anuncios")
public class AnuncioController {
    @Autowired 
    private AnuncioService anuncioService;
    //EndPoints = EndP

    @Operation(summary = "EndPoint para encontrar todos los Anuncios")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos los Anuncios",
        content=@Content(schema=@Schema(implementation=Anuncio.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Anuncio registrado",
        content =@Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Anuncio.class)))
    })
    @GetMapping
    public ResponseEntity<List<Anuncio>> obtenerAnuncios(){
        List<Anuncio> anuncios = anuncioService.getAnuncios();
        if(anuncios.isEmpty()){
            //si esta vacia = 204
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(anuncios);
    }

    @Operation(summary = "EndPoint para encontrar un solo Anuncio mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró el Anuncio por Id",
        content=@Content(schema=@Schema(implementation=Anuncio.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Anuncio.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Anuncio> obtenerAnuncioId(@PathVariable Long id){
        try {
            Anuncio anuncio = anuncioService.getAnuncio(id);
            return ResponseEntity.ok(anuncio);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
            //si no existe = 404
        } 
    }

    @Operation(summary = "EndPoint para guardar un Anuncio")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Anuncio guardado exitosamente",
        content=@Content(schema=@Schema(implementation=Anuncio.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Anuncio.class)))
    })
    @PostMapping
    public ResponseEntity<Anuncio> guardarAnuncio(@RequestBody Anuncio anuncio){
        return ResponseEntity.status(201).body(anuncioService.saveAnuncio(anuncio));
    }

    @Operation(summary = "EndPoint para actualizar un Anuncio y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Anuncio actualizado exitosamente",
        content=@Content(schema=@Schema(implementation=Anuncio.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="404", description="No se encontró el anuncio",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Anuncio.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Anuncio> actualizarAnuncio(@PathVariable Long id, @RequestBody Anuncio anuncio){
        try {
            Anuncio anuncio2 = anuncioService.updateAnuncio(id, anuncio);
            return ResponseEntity.ok(anuncio2);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para eliminar un Anuncio")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Anuncio eliminado exitosamente",
        content=@Content(schema=@Schema(implementation=Anuncio.class))),
        @ApiResponse(responseCode="404", description="No se encontró el anuncio",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Anuncio.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Anuncio.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarAnuncio(@PathVariable Long id){
        try {
            anuncioService.deleteAnuncio(id);
            return ResponseEntity.noContent().build(); 
            //204 si fue correcto
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); 
            //404 si no existia
        }
    }


}
