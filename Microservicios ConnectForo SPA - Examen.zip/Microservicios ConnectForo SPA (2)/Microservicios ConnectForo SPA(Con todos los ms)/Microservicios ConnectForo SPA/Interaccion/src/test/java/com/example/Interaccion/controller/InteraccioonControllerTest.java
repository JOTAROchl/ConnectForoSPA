package com.example.Interaccion.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import com.example.Interaccion.model.Interaccion;
import com.example.Interaccion.repository.InteraccionRepository;
import com.example.Interaccion.service.InteraccionService;

@WebMvcTest(InteraccioonController.class)
public class InteraccioonControllerTest {

    @MockBean
    private InteraccionService interaccionService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllReservas_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<Interaccion> interaccions = Arrays.asList(new Interaccion(1L, new Date(0), "Me gusta", "Foro", 1L));

        //configuro el comportamiento del servicio simulado
        when(interaccionService.getInteracciones()).thenReturn(interaccions);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/interacciones")).andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
