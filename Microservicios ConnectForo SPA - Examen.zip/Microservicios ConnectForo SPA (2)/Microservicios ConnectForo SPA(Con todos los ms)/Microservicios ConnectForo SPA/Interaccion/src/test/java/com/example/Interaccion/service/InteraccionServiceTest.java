package com.example.Interaccion.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Interaccion.model.Interaccion;
import com.example.Interaccion.repository.InteraccionRepository;
import com.example.Interaccion.webclient.UsuarioUser;

@ExtendWith(MockitoExtension.class)
public class InteraccionServiceTest {
    @Mock
    private InteraccionRepository repository;
    @Mock
    private UsuarioUser usuarioUser;

    @InjectMocks
    private InteraccionService service;

    @Test
    void saveInteraccion_returnsSavedInteraccion(){
        //creamos un objeto de prueba para el insert
        Interaccion nuevaInteraccion = new Interaccion(1L, new Date(0), "Me gusta", "Foro", 1L);
        //configuramos la respuesta del repositorio
        
        when(usuarioUser.obtenerUsuarioId(1L))
        .thenReturn(Map.of("id", 1L, "nombreUsuario","Thomas","correo","th.ferra@duocuc.cl","clave","1234","rolId",1L,"estadoId",1L));
        when(repository.save(nuevaInteraccion)).thenReturn(nuevaInteraccion);

        //ejecutamos el metodo del servicio a comprobar
        Interaccion result = service.saveInteraccion(nuevaInteraccion);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevaInteraccion); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getInteracciones_returnsListOfInteracciones() {
        List<Interaccion> mockList = Arrays.asList(
            new Interaccion(1L, new Date(0), "Me gusta", "Foro", 1L),
            new Interaccion(2L, new Date(0), "Comentar", "Post", 2L)
        );
        when(repository.findAll()).thenReturn(mockList);
        List<Interaccion> result = service.getInteracciones();
        assertThat(result).isEqualTo(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getInteraccion_returnsInteraccionById(){
        //creamos un objeto de prueba para el insert
        Interaccion interaccion = new Interaccion(1L, new Date(0), "Me gusta", "Foro", 1L);
        
        //configuramos el repositorio para que devuelva la interaccion por id
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(interaccion));

        //ejecutamos el metodo del servicio a comprobar
        Interaccion result = service.getInteraccion(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(interaccion);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateInteraccion_returnsUpdatedInteraccion() {
        //creamos un objeto de prueba para el insert
        Interaccion interaccion1 = new Interaccion(1L, new Date(0), "Me gusta", "Foro", 1L);
        Interaccion interaccion2 = new Interaccion(1L, new Date(0), "No me gusta", "Post", 2L);

        //configuramos el repositorio para que devuelva la interaccion actualizada
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(interaccion1));
        when(repository.save(interaccion2)).thenReturn(interaccion2);

        //ejecutamos el metodo del servicio a comprobar
        Interaccion result = service.updateInteraccion(1L, interaccion2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(interaccion2); //el mismo objeto
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteInteraccion_deletesInteraccionById() {
        //creamos un objeto de prueba para el insert
        Interaccion interaccion = new Interaccion(1L, new Date(0), "Me gusta", "Foro", 1L);
        //configuramos el repositorio para que devuelva la interaccion por id
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(interaccion));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteInteraccion(1L);

        //verificamos que el repositorio haya llamado al metodo delete con la interaccion correcta
        assertThat(repository.findById(1L).isEmpty());
    }
}
