package com.example.Interaccion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Interaccion.model.Interaccion;
@Repository
public interface InteraccionRepository extends JpaRepository <Interaccion, Long>{

}
