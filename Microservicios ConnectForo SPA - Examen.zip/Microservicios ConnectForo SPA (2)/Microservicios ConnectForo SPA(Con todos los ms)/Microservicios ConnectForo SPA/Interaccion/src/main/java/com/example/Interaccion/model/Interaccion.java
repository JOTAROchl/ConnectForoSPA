package com.example.Interaccion.model;

import java.sql.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "interaccion")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "interacciones las cuales se hacen a distintos elementos")
public class Interaccion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador unico de la Interaccion")
    private Long id;

    @Column(name = "fecha_interaccion", nullable = false)
    @Schema(description = "Fecha en que se hizo la Interaccion")
    private Date fecInteraccion;

    @Column(nullable = false, length = 50)
    @Schema(description = "Tipo de Interaccion que se hace al elemento")
    private String tipoInteraccion;

    @Column(nullable = false, length = 50)
    @Schema(description = "Tipo del elemento Interactuado")
    private String tipoElemento;

    @Column(nullable = false)
    @Schema(description = "Usuario dueño del elemento Interactuado")
    private Long usuarioId;

}
