package com.example.Interaccion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Interaccion.model.Interaccion;
import com.example.Interaccion.service.InteraccionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/interacciones")
public class InteraccioonController {
    @Autowired
    private InteraccionService interaccionService;


    @Operation(summary = "EndPoint para encontrar todos las Interacciones")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos las Interacciones",
        content=@Content(schema=@Schema(implementation=Interaccion.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Interaccion registrado",
        content =@Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Interaccion.class)))
    })
    @GetMapping
    public ResponseEntity<List<Interaccion>> obtenerInteraccion(){
        List<Interaccion> interaccion = interaccionService.getInteracciones();
        if(interaccion.isEmpty()){
            //si esta vacia = 204
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(interaccion);
    }   

    @Operation(summary = "EndPoint para encontrar un solo Interaccion mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró el Interaccion por Id",
        content=@Content(schema=@Schema(implementation=Interaccion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Interaccion.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Interaccion> obtenerInteraccionId(@PathVariable Long id){
        try {
            Interaccion interaccion = interaccionService.getInteraccion(id);
            return ResponseEntity.ok(interaccion);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
            //si no existe = 404
        } 
    }

    @Operation(summary = "EndPoint para guardar una Interaccion")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Interaccion guardada exitosamente",
        content=@Content(schema=@Schema(implementation=Interaccion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Interaccion.class)))
    })
    @PostMapping
    public ResponseEntity<Interaccion> guardarInteraccion(@RequestBody Interaccion interaccion){
        
        return ResponseEntity.status(201).body(interaccionService.saveInteraccion(interaccion));
    }

    @Operation(summary = "EndPoint para actualizar una Interaccion y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Interaccion actualizada exitosamente",
        content=@Content(schema=@Schema(implementation=Interaccion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="404", description="No se encontró la interaccion",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Interaccion.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Interaccion> actualizarReporte(@PathVariable Long id, @RequestBody Interaccion interaccion){
        try {
            Interaccion interaccion2 = interaccionService.updateInteraccion(id, interaccion);
            return ResponseEntity.ok(interaccion2);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para eliminar una Interaccion")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Interaccion eliminada exitosamente",
        content=@Content(schema=@Schema(implementation=Interaccion.class))),
        @ApiResponse(responseCode="404", description="No se encontró la interaccion",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Interaccion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Interaccion.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarInteraccion(@PathVariable Long id){
        try {
            interaccionService.deleteInteraccion(id);
            return ResponseEntity.noContent().build(); 
            //204 si fue correcto
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); 
            //404 si no existia
        }
    }
}
