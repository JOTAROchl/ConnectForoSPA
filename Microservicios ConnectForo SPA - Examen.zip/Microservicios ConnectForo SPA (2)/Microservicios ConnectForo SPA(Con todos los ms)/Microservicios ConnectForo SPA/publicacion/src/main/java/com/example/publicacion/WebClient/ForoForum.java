package com.example.publicacion.WebClient;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class ForoForum {
    private final WebClient webClient;
    
    public ForoForum(@Value("${foro-service.url}") String foroServidor ){
        this.webClient = WebClient.builder().baseUrl(foroServidor).build();
    }

    //metrodo para comunicarme con el microservicio de estados
    //Estado y verifica si existe
    //devuelve una estructura de mapa que representa el json
    public Map<String, Object> obtenerForoId(Long id){
        //realiza un consulta HTTP de tipo get al microservicio
        return this.webClient.get()
        .uri("/{id}", id)
        .retrieve()
        .onStatus(status -> status.is4xxClientError(),
        response -> response.bodyToMono(String.class)
        .map(body -> new RuntimeException("Foro no encontrado"))).bodyToMono(Map.class).block();
    }
}
