package com.example.publicacion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.publicacion.model.Publicacion;

@Repository
public interface PublicacionRepository extends JpaRepository <Publicacion, Long>{

}
