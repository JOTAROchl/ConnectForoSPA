package com.example.publicacion.model;

import java.util.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "publicacion")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Publicaciones hechas en foros por los usuarios")
public class Publicacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "identificador unico de la publicaicon")
    private Long id;

    @Column(nullable = false, length = 120)
    @Schema(description = "titulo de esta")
    private String titulo;

    @Column(name = "fecha_publicacion", nullable = false)
    @Schema(description = "fecha en que se hizo")
    private Date fecPublicacion;

    @Column(nullable = false, length = 30)
    @Schema(description = "prioridad de la publicacion")
    private String prioridad;

    @Column(nullable = false, length = 50)
    @Schema(description = "donde se hizo")
    private String lugar;

    @Column(nullable = false, length = 500)
    @Schema(description = "contenido de la publicacion")
    private String descripcion;

    @Column(nullable = false)
    @Schema(description = "estado de esta")
    private Long estadoId;

    @Column(nullable = false)
    @Schema(description = "quien la hizo")
    private Long usuarioId;

    @Column(nullable = false)
    @Schema(description = "Foro donde la publico")
    private Long foroId;
}
