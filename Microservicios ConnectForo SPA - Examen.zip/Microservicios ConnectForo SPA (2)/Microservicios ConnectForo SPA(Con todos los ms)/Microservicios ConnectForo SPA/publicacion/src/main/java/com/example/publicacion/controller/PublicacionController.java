package com.example.publicacion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.publicacion.model.Publicacion;
import com.example.publicacion.service.PublicacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/publicaciones")

public class PublicacionController {

    @Autowired 
    private PublicacionService publicacionService;

    @Operation(summary = "EndPoint para encontrar todos las Publicaciones")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos las Publicaciones",
        content=@Content(schema=@Schema(implementation=Publicacion.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Publicacion registrado",
        content =@Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Publicacion.class)))
    })
    @GetMapping
    public ResponseEntity<List<Publicacion>> obtenerPublicaciones(){
        List<Publicacion> publicacion = publicacionService.getPublicaciones();
        //si esta vacia = 204
        if (publicacion.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(publicacion);
    }

    @Operation(summary = "EndPoint para encontrar una sola Publicacion mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró la Publicacion por Id",
        content=@Content(schema=@Schema(implementation=Publicacion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Publicacion.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Publicacion> obtenerPublicacionId(@PathVariable Long id){
        try {
            Publicacion publicacion = publicacionService.getPublicacionById(id);
            return ResponseEntity.ok(publicacion);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
            //si no existe = 404
        } 
    }

    @Operation(summary = "EndPoint para guardar una Publicacion")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Publicacion guardada exitosamente",
        content=@Content(schema=@Schema(implementation=Publicacion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Publicacion.class)))
    })
    @PostMapping
    public ResponseEntity<Publicacion> guardarPublicacion(@RequestBody Publicacion publicacion){
        return ResponseEntity.status(201).body(publicacionService.savePublicacion(publicacion));
    }

    @Operation(summary = "EndPoint para actualizar una Publicacion y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Publicacion actualizada exitosamente",
        content=@Content(schema=@Schema(implementation=Publicacion.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="404", description="No se encontró la publicacion",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Publicacion.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Publicacion> actualizarPublicacion(@PathVariable Long id, @RequestBody Publicacion publicacion){
        try {
            Publicacion publicacion2 = publicacionService.updatePublicacion(id, publicacion);
            return ResponseEntity.ok(publicacion2);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para eliminar un Publicacion")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Publicacion eliminada exitosamente",
        content=@Content(schema=@Schema(implementation=Publicacion.class))),
        @ApiResponse(responseCode="404", description="No se encontró la publicacion",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Publicacion.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Publicacion.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPublicacion(@PathVariable Long id){
        try {
            publicacionService.deletePublicacion(id);
            return ResponseEntity.noContent().build();
            //204 si fue correcto
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); 
            //404 si no existia
        }
    }




}
