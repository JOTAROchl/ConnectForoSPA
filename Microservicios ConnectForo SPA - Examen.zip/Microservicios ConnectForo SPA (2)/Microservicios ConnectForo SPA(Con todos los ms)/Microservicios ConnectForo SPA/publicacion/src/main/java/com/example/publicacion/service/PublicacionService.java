package com.example.publicacion.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.publicacion.WebClient.EstadoStatus;
import com.example.publicacion.WebClient.ForoForum;
import com.example.publicacion.WebClient.usuarioUser;
import com.example.publicacion.model.Publicacion;
import com.example.publicacion.repository.PublicacionRepository;
//import com.example.comentario.webclient.EstadoStatus;
//import com.example.comentario.webclient.UsuarioUser;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class PublicacionService {
    @Autowired
    private PublicacionRepository publicacionRepository;
    @Autowired
    private EstadoStatus estadoStatus;
    @Autowired
    private ForoForum foroForum;
    @Autowired
    private usuarioUser usuariouser;

    //MTD para obtener todos
    @Schema(description = "Metodo para obtener todas")
    public List<Publicacion> getPublicaciones(){
        return publicacionRepository.findAll();
    }

    @Schema(description = "Metodo para obtener una por su id")
    public Publicacion getPublicacionById(Long id){
        return publicacionRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Publicacion no encontrada"));
    }

    //MTD para guardar publicacion
    @Schema(description = "Metodo para guardar una")
    public Publicacion savePublicacion(Publicacion publicacion) {

        Map<String, Object> Estado = estadoStatus.obtenerEstadoId(publicacion.getEstadoId());
        if (Estado == null || Estado.isEmpty()) {
            throw new RuntimeException("Estado no encontrado, no se puede agregar Publicacion*******************************************");
        }

        Map<String, Object> Foro = foroForum.obtenerForoId(publicacion.getForoId());
        if (Foro == null || Foro.isEmpty()) {
            throw new RuntimeException("Foro no encontrado, no se puede agregar Publicacion*******************************************");
        }

        Map<String, Object> Usuario = usuariouser.obtenerUsuarioId(publicacion.getUsuarioId());
        if (Usuario == null || Usuario.isEmpty()) {
            throw new RuntimeException("Usuario no encontrado, no se puede agregar Publicacion*******************************************");
        }

        return publicacionRepository.save(publicacion);
    }

    //MTD para actualizar
    @Schema(description = "Metodo para actulizar los datos de una")
    public Publicacion updatePublicacion(Long id, Publicacion publicacionDetalle) {
        //verifica si el publicacion existe
        Publicacion publicacion = publicacionRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Publicacion no encontrada"));

        //actualiza
        publicacion.setTitulo(publicacionDetalle.getTitulo());
        publicacion.setFecPublicacion(publicacionDetalle.getFecPublicacion());
        publicacion.setDescripcion(publicacionDetalle.getDescripcion());
        publicacion.setLugar(publicacionDetalle.getLugar());
        publicacion.setPrioridad(publicacionDetalle.getPrioridad());
        publicacion.setEstadoId(publicacionDetalle.getEstadoId());
        publicacion.setUsuarioId(publicacionDetalle.getUsuarioId());
        publicacion.setForoId(publicacionDetalle.getForoId());
        //guarda
        return publicacionRepository.save(publicacion);
    }

    @Schema(description = "Metodo para eliminar una publicaicon")
    public void deletePublicacion(Long id){
        Publicacion publicacion = publicacionRepository.findById(id)
        //si no lo encuentra, se cancela
        .orElseThrow(() -> new RuntimeException("Publicacion no encontrada"));
        //extermina el usuario
        publicacionRepository.delete(publicacion);
    }

    //MTD para historial de las publicaciones
    @Schema(description = "Metodo para ver el historial de publicaciones de un usuario")
    public List<Publicacion> getPublicacionByUsuarioId(Long usuarioId) {
        return publicacionRepository.findAll().stream()
            .filter(publicacion -> publicacion.getUsuarioId().equals(usuarioId))
            .toList();
    }
}
