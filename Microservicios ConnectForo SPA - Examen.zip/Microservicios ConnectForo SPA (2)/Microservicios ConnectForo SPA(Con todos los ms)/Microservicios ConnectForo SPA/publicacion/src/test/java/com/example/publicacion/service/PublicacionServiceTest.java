package com.example.publicacion.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.sql.Date;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.publicacion.model.Publicacion;
import com.example.publicacion.repository.PublicacionRepository;


@ExtendWith(MockitoExtension.class)
public class PublicacionServiceTest {
    @Mock
    private PublicacionRepository repository;

    @InjectMocks
    private PublicacionService service;
    /* 
    @Test
    void savePublicacion_returnsSavedPublicacion(){
        //creamos un objeto de prueba para el insert
        Publicacion nuevaPublicacion = new Publicacion
        (1L,"Titulo", new Date(0),"alta", "foro animales","Descripcion", 1L, 1L, 1L);

        //configuramos la respuesta del repositorio
        // Mockea la respuesta de los webclients
        when(repository.save(nuevaPublicacion)).thenReturn(nuevaPublicacion);

        Publicacion result = service.savePublicacion(nuevaPublicacion);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevaPublicacion); //el mismo objeto
    }*/
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getPublicaciones_returnsListOfPublicaciones() {
        List<Publicacion> mockList = List.of(new Publicacion(1L, "Titulo1", new Date(0), "alta", "foro animales", "Descripcion1", 1L, 1L, 1L),
                                              new Publicacion(2L, "Titulo2", new Date(0), "alta", "foro plantas", "Descripcion2", 1L, 1L, 1L));
        when(repository.findAll()).thenReturn(mockList);
        List<Publicacion> result = service.getPublicaciones();
        assertThat(result).isEqualTo(mockList);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getPublicacion_returnPublicacionById() {
        //creamos un objeto de prueba para el insert
        Publicacion publicacion1 = new Publicacion
        (1L,"Titulo1", new Date(0),"alta", "foro animales","Descripcion1", 1L, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(publicacion1));

        //ejecutamos el metodo del servicio a comprobar
        Publicacion result = service.getPublicacionById(1L);

        //comprobamos que el resultado es el esperado
        assertThat(result).isSameAs(publicacion1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updatePublicacion_returnsUpdatedPublicacion() {
        //creamos un objeto de prueba para el insert
        Publicacion publicacion1 = new Publicacion
        (1L,"Titulo1", new Date(0),"alta", "foro animales","Descripcion1", 1L, 1L, 1L);
        Publicacion publicacion2 = new Publicacion
        (2L,"Titulo2", new Date(0),"alta", "foro plantas","Descripcion2", 1L, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(publicacion1));
        when(repository.save(publicacion1)).thenReturn(publicacion1);
        //ejecutamos el metodo del servicio a comprobar
        Publicacion result = service.updatePublicacion(1L, publicacion2);

        //comprobamos que el resultado es el esperado
        assertThat(publicacion1.getTitulo()).isEqualTo("Titulo2");
        assertThat(result).isSameAs(publicacion1);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deletePublicacion_returnsDeletedPublicacion() {
        //creamos un objeto de prueba para el insert
        Publicacion publicacion1 = new Publicacion
        (1L,"Titulo1", new Date(0),"alta", "foro animales","Descripcion1", 1L, 1L, 1L);
        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(publicacion1));

        //ejecutamos el metodo del servicio a comprobar
        service.deletePublicacion(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el usuario correcto
        assertThat(repository.findById(1L).isEmpty());
    }
}
