package com.example.publicacion.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.publicacion.model.Publicacion;
import com.example.publicacion.service.PublicacionService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

@WebMvcTest(PublicacionController.class)
public class PublicacionControllerTest {

        //inyectamos un mock de ReservaService para manipular nuestro contexto
    @MockBean
    private PublicacionService publicacionService;

    //se inyecta un mock proporcionado por spring para simular la llamada a la api
    private MockMvc mockMvc;

    @Test
    void getPublicaciones_returnsOkAndJson(){
        //creamos un rol de ejemplo
        List<Publicacion> publicaciones = Arrays.asList(new Publicacion(1L,"Titulo1", new Date(0),"alta", "foro animales","Descripcion1", 1L, 1L, 1L),
                                                        new Publicacion(2L,"Titulo2", new Date(0),"alta", "foro plantas","Descripcion2", 1L, 1L, 1L));

        //configuro el comportamiento del servicio simulado
        when(publicacionService.getPublicaciones()).thenReturn(publicaciones);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/publicaciones"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getPublicacion_returnsOkAndJson() {
        //creamos un objeto de ejemplo
        Publicacion publicacion = new Publicacion(1L, "Titulo1", new Date(0), "alta", "foro animales", "Descripcion1", 1L, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(publicacionService.getPublicacionById(1L)).thenReturn(publicacion);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/publicaciones/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */

    @Test
    void savePublicacion_returnsCreatedAndJson() {
        //creamos un objeto de ejemplo
        Publicacion publicacion = new Publicacion(1L, "Titulo1", new Date(0), "alta", "foro animales", "Descripcion1", 1L, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(publicacionService.savePublicacion(publicacion)).thenReturn(publicacion);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201

        try {
            mockMvc.perform(post("api/v1/publicaciones")
                    .contentType("application/json")
                    .content("{\"id\":1,\"titulo\":\"Titulo1\",\"fechaPublicacion\":\"2023-01-01\",\"prioridad\":\"alta\",\"lugar\":\"foro animales\",\"descripcion\":\"Descripcion1\",\"estadoId\":1,\"usuarioId\":1,\"foroId\":1}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id")
                    .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }   

    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updatePublicacion_returnsUpdatedPublicacion() {
        //creamos un objeto de ejemplo
        Publicacion publicacion = new Publicacion(1L, "Titulo1", new Date(0), "alta", "foro animales", "Descripcion1", 1L, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(publicacionService.updatePublicacion(1L, publicacion)).thenReturn(publicacion);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(put("api/v1/publicaciones/1")
                    .contentType("application/json")
                    .content("{\"id\":1,\"titulo\":\"Titulo1\",\"fechaPublicacion\":\"2023-01-01\",\"prioridad\":\"alta\",\"lugar\":\"foro animales\",\"descripcion\":\"Descripcion1\",\"estadoId\":1,\"usuarioId\":1,\"foroId\":1}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
