package com.example.Foro.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.OpenAPI;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI apiInfo(){
        return new OpenAPI()
        .info(new Info()
            .title("Foro API")
            .version("1.0")
            .description("Foro en donde los usuarios puedan crear Publicaciones ConnectForoSPA"));
    }
}