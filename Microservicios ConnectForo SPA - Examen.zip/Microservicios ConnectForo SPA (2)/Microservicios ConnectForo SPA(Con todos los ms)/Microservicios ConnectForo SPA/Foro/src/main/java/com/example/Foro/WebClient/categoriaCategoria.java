package com.example.Foro.WebClient;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
@Component
public class categoriaCategoria {
    private final WebClient webClient;

    public categoriaCategoria(@Value("${categoria-service.url}") String categoriaServidor){
        this.webClient = WebClient.builder().baseUrl(categoriaServidor).build();
    }

    public Map<String, Object> obtenerCategoriaId(Long id){
        //realiza un consulta HTTP de tipo get al microservicio
        return this.webClient.get()
        .uri("/{id}", id)
        .retrieve()
        .onStatus(status -> status.is4xxClientError(),
        response -> response.bodyToMono(String.class)
        .map(body -> new RuntimeException("Categoria no encontrada"))).bodyToMono(Map.class).block();
    }
}
