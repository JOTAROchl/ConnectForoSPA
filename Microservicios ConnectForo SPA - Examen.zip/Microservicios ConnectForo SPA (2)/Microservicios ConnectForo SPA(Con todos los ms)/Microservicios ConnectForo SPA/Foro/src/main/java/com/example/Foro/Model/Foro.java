package com.example.Foro.Model;


import java.util.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "foro")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Foros donde los Usuarios puedan hacer publicaciones")
public class Foro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_foro")
    @Schema(description = "identificador unico") 
    private Long idForo;

    @Column(nullable = false, length = 20)
    @Schema(description = "nombre del foro") 
    private String nombreForo;

    @Column(name="fecha_creacion", nullable = false)
    @Schema(description = "cuando se hizo el foro") 
    private Date fechaCreacion;

    @Column(name="fecha_baneo", nullable = true)
    @Schema(description = "fecha en que se baneo el foro") 
    private Date fechaBaneo;

    @Column(nullable = true, length = 250)
    @Schema(description = "razon del baneo") 
    private String razonBaneo;

    @Column(nullable = false)
    @Schema(description = "identificador del que hizo el foro") 
    private Long idUsuario;

    @Column(nullable = false)
    @Schema(description = "estado actual") 
    private Long idEstado;

    @Column(nullable = false)
    @Schema(description = "de que categoria es") 
    private Long idCategoria;

}
