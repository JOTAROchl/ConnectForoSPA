package com.example.Foro.Service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Foro.Model.Foro;
import com.example.Foro.Repository.ForoRepository;
import com.example.Foro.WebClient.EstadoStatus;
import com.example.Foro.WebClient.UsuarioUser;
import com.example.Foro.WebClient.categoriaCategoria;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ForoService {
    @Autowired
    private ForoRepository foroRepository;
    @Autowired
    private UsuarioUser usuarioUser;
    @Autowired
    private EstadoStatus estadoStatus;
    @Autowired
    private categoriaCategoria categoriaCategoria;
    
    @Schema(description = "Metodo para obtener todos") 
    public List<Foro> getAllForos() {
        return foroRepository.findAll();
    }

    @Schema(description = "Metodo para obtener uno por su id")
    public Foro getForo(Long id) {
        return foroRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("Foro no encontrado"));
    }

    @Schema(description = "Metodo para guardar uno")
    public Foro saveForo(Foro foro) {

        Map<String, Object> usuario = usuarioUser.obtenerUsuarioId(foro.getIdUsuario());
        if (usuario == null || usuario.isEmpty()) {
            throw new RuntimeException("Usuario no encontrado, no se puede agregar Foro");
        }

        Map<String, Object> Estado = estadoStatus.obtenerEstadoId(foro.getIdEstado());
        if (Estado == null || Estado.isEmpty()) {
            throw new RuntimeException("Estado no encontrado, no se puede agregar Foro");
        }

        Map<String, Object> categoria = categoriaCategoria.obtenerCategoriaId(foro.getIdCategoria());
        if (categoria == null || categoria.isEmpty()) {
            throw new RuntimeException("Categoria no encontrado, no se puede agregar Foro");
        }
        return foroRepository.save(foro);
    }

    @Schema(description = "Metodo para actulizar los datos de un Foro")
    public Foro updateForo(long id, Foro foro) {
        Foro foro2 = foroRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Foro no encontrado"));
        
        foro2.setNombreForo(foro.getNombreForo());
        foro2.setFechaCreacion(foro.getFechaCreacion());
        foro2.setFechaBaneo(foro.getFechaBaneo());
        foro2.setRazonBaneo(foro.getRazonBaneo());
        foro2.setIdUsuario(foro.getIdUsuario());
        foro2.setIdCategoria(foro.getIdCategoria());
        foro2.setIdEstado(foro.getIdEstado());

        return foroRepository.save(foro2);
    }

    @Schema(description = "Metodo para eliminar un foro")    
    public void deleteForo(long id) {
        Foro foro = foroRepository.findById(id)
        .orElseThrow(()-> new RuntimeException("Foro no encontrado"));

        foroRepository.delete(foro);
    }

}
