package com.example.Foro.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Foro.Model.Foro;
import com.example.Foro.Service.ForoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;


@RestController
@RequestMapping("/api/v1/foros")
public class ForoController {
    @Autowired
    private ForoService foroService;

    @Operation(summary = "EndPoint para encontrar todos los Foros")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Generó la lista con todos los Foros",
        content=@Content(schema=@Schema(implementation=Foro.class))),
        @ApiResponse(responseCode="204", description="No hay ningun Foro registrado",
        content =@Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Foro.class)))
    })
    @GetMapping
    public ResponseEntity<List<Foro>> obtenerForos(){
        List<Foro> foros = foroService.getAllForos();
        if (foros.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(foros);
    }

    @Operation(summary = "EndPoint para encontrar un solo Foro mediante su Id")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Se encontró el Foro por Id",
        content=@Content(schema=@Schema(implementation=Foro.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="404", description="No se encontró el recurso",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor, verifique si el datos ingresado es ya existe o hay una falla en la base de datos",
        content = @Content(schema = @Schema(implementation = Foro.class)))
    })
    @GetMapping("/{id}")
    public ResponseEntity<Foro> obtenerForoPorId(@PathVariable Long id){
        try{
            Foro foro = foroService.getForo(id);
            return ResponseEntity.ok(foro);
        }catch (Exception e) {
            return ResponseEntity.notFound().build();
        }        
    }

    @Operation(summary = "EndPoint para guardar un Foro")
    @ApiResponses( value = {
        @ApiResponse(responseCode="201", description="Foro guardado exitosamente",
        content=@Content(schema=@Schema(implementation=Foro.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Foro.class)))
    })
    @PostMapping
    public ResponseEntity<Foro> guardarForo(@RequestBody Foro foro){
        return ResponseEntity.status(201).body(foroService.saveForo(foro)); // devuelve el codigo 201 (Created) si se guarda correctamente
    }

    @Operation(summary = "EndPoint para actualizar un Foro y todos sus datos")
    @ApiResponses( value = {
        @ApiResponse(responseCode="200", description="Foro actualizado exitosamente",
        content=@Content(schema=@Schema(implementation=Foro.class))),
        @ApiResponse(responseCode="400", description="Solicitud incorrecta, verifique los datos",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="404", description="No se encontró el foro",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Foro.class)))
    })
    @PutMapping("/{id}")
    public ResponseEntity<Foro> actualizarForo(@PathVariable Long id, @RequestBody Foro foro) {
        try{
            Foro foroActualizado = foroService.updateForo(id, foro);
            return ResponseEntity.ok(foroActualizado);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "EndPoint para eliminar un Foro")
    @ApiResponses( value = {
        @ApiResponse(responseCode="204", description="Foro eliminado exitosamente",
        content=@Content(schema=@Schema(implementation=Foro.class))),
        @ApiResponse(responseCode="404", description="No se encontró el foro",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="405", description="Método no permitido",
        content = @Content(schema = @Schema(implementation = Foro.class))),
        @ApiResponse(responseCode="500", description="Error interno del servidor",
        content = @Content(schema = @Schema(implementation = Foro.class)))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarForo(@PathVariable Long id){
        try{
            foroService.deleteForo(id); // llama al servicio para eliminar la categoria por id
            return ResponseEntity.noContent().build();// devolverá el codigo 204 (No Content) si la categoria se elimina correctamente
        } catch (Exception e){
            return ResponseEntity.notFound().build(); // si no encuentra la categoria, devolverá el codigo 404 (Not Found)
        }
    }
}
