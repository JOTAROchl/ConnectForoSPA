package com.example.Foro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoApplicationTests {

	@Test
	void contextLoads() {
	}

}
