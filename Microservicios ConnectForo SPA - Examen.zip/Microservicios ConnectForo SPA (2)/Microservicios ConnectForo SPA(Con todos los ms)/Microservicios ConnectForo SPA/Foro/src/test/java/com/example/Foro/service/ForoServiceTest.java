package com.example.Foro.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.Map;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.Foro.Model.Foro;
import com.example.Foro.Repository.ForoRepository;
import com.example.Foro.Service.ForoService;
import com.example.Foro.WebClient.EstadoStatus;
import com.example.Foro.WebClient.UsuarioUser;
import com.example.Foro.WebClient.categoriaCategoria;


@ExtendWith(MockitoExtension.class)
public class ForoServiceTest {
    @Mock
    private ForoRepository repository;
    @Mock
    private UsuarioUser usuarioUser;
    @Mock
    private EstadoStatus estadoStatus;
    @Mock
    private categoriaCategoria categoriaCategoria;

    @InjectMocks
    private ForoService service;
    /* 
    @Test
    void saveForo_returnsSavedForo(){
        //creamos un objeto de prueba para el insert
        Foro nuevoForo = new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L);
        //configuramos la respuesta del repositorio
    
        when(repository.save(nuevoForo)).thenReturn(nuevoForo);

        //ejecutamos el metodo del servicio a comprobar
        Foro result = service.saveForo(nuevoForo);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(nuevoForo); //el mismo objeto
    } */
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getForos_returnsListOfForos() {
        List<Foro> mockList = Arrays.asList(new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L),
                                       new Foro(2L, "Plantitas", new Date(0), null, null, 1L, 1L, 1L));
        when(repository.findAll()).thenReturn(mockList);
        List<Foro> result = service.getAllForos();
        assertThat(result).isEqualTo(mockList);
    }
        /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getForo_returnsForoById() {
        //creamos un objeto de prueba para el select
        Foro foro = new Foro(1L, "Usuario", new Date(0), null, null, 1L, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(foro));

        //ejecutamos el metodo del servicio a comprobar
        Foro result = service.getForo(1L);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(result).isSameAs(foro);
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateForo_returnsUpdatedForo() {   
        //creamos un objeto de prueba para el update
        Foro foro1 = new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L);
        Foro foro2 = new Foro(1L, "Plantitas", new Date(0), null, null, 1L, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(foro1));
        when(repository.save(foro1)).thenReturn(foro1);

        //ejecutamos el metodo del servicio a comprobar
        Foro result = service.updateForo(1L, foro2);

        //comprobamos que el servicio devuelva lo mismo que el repositorio
        assertThat(foro1.getNombreForo()).isEqualTo("Plantitas");
        assertThat(result).isSameAs(foro1);
    }
        /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void deleteForo_deletesForoById() {
        //creamos un objeto de prueba para el delete
        Foro foro = new Foro(1L, "Usuario", new Date(0), null, null, 1L, 1L, 1L);

        //configuramos la respuesta del repositorio
        when(repository.findById(1L)).thenReturn(java.util.Optional.of(foro));

        //ejecutamos el metodo del servicio a comprobar
        service.deleteForo(1L);

        //verificamos que el repositorio haya llamado al metodo delete con el foro correcto
        assertThat(repository.findById(1L).isEmpty());

    }
}
