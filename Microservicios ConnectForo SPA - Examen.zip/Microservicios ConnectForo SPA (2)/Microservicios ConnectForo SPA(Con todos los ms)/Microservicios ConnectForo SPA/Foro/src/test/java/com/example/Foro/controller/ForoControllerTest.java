package com.example.Foro.controller;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.example.Foro.Controller.ForoController;
import com.example.Foro.Model.Foro;
import com.example.Foro.Service.ForoService;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@WebMvcTest(ForoController.class)
public class ForoControllerTest {
    @MockBean
    private ForoService foroService;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getAllForos_returnsOKAndJson(){
        //creamos una reserva de ejemplo
        List<Foro> foros = Arrays.asList(new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L));

        //configuro el comportamiento del servicio simulado
        when(foroService.getAllForos()).thenReturn(foros);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200
        try {
            mockMvc.perform(get("/api/v1/foros"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[0].idForo")
            .value(1L));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
/*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void getForo_returnsOkAndJson() {
        //creamos un foro de ejemplo
        Foro foro = new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(foroService.getForo(1L)).thenReturn(foro);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo get con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(get("api/v1/foros/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id")
            .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void saveForo_returnsCreatedAndJson() {
        //creamos un foro de ejemplo
        Foro foro = new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(foroService.saveForo(foro)).thenReturn(foro);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo post con la url
        //verificar que retorna el codigo 201

        try {
            mockMvc.perform(post("api/v1/foros")
                    .contentType("application/json")
                    .content("{\"id\":1,\"nombre\":\"Animalitos\",\"fechaCreacion\":\"2023-01-01\",\"fechaBaneo\":\"null\",\"razonBaneo\":null,\"idUsuario\":1,\"idEstado\":1,\"idCategoria\":1}"))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.id")
                    .value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }   

    }
    private MockHttpServletRequestBuilder post(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'post'");
    }
    /*----------------------------------------- Espaciado ----------------------------------------- */
    @Test
    void updateForo_returnsUpdatedForo() {
        //creamos un foro de ejemplo
        Foro foro = new Foro(1L, "Animalitos", new Date(0), null, null, 1L, 1L, 1L);

        //configuro el comportamiento del servicio simulado
        when(foroService.updateForo(1L, foro)).thenReturn(foro);

        //ejecutar el endpoint del controlador a probar
        //mandar a ejecutar le metodo put con la url
        //verificar que retorna el codigo 200

        try {
            mockMvc.perform(put("api/v1/foros/1")
                    .contentType("application/json")
                    .content("{\"id\":1,\"nombre\":\"Animalitos\",\"fechaCreacion\":\"2023-01-01\",\"fechaBaneo\":\"null\",\"razonBaneo\":null,\"idUsuario\":1,\"idEstado\":1,\"idCategoria\":1}"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private MockHttpServletRequestBuilder put(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'put'");
    }
}
