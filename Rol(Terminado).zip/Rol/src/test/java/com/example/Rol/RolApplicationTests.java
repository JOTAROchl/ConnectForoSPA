package com.example.Rol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolApplicationTests {

	@Test
	void contextLoads() {
	}

}
