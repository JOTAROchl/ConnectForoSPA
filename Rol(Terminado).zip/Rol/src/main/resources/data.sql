INSERT INTO roles (nombreRol) VALUES ('Administrador');
INSERT INTO roles (nombreRol) VALUES ('Usuario');
INSERT INTO roles (nombreRol) VALUES ('Moderador');
